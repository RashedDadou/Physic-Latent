# sd_tool.py
"""
منسق عمليات الفلترة والمراقبة لـ Latent Space (SD Latent Coordinator / sd_tool).
المسؤولية:
1. الربط التكاملي بين محرك المراقبة (LatentInjectionMonitor) ومحرك الفلترة (LatentFilterEngine).
2. تقييم خطوة الـ Denoising الحالية وتنفيذ الفلترة أو الحقن المتردد بصراحة ووضوح.
3. إدارة سياق المعالجة (device و dtype) وتطبيقهما بصرامة على كامل السلسلة الحسابية.
"""

from __future__ import annotations

import logging
from typing import Dict, Any, Tuple
import torch

from sd_latent_filter import LatentFilterEngine
from sd_latent_monitor import LatentInjectionMonitor

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("SD_LATENT_COORDINATOR")


class SD_tools:
    """منسق العمليات المباشر بين المراقب والفلتر لـ Latent Space."""

    def __init__(
        self,
        monitor_engine: LatentInjectionMonitor,
        filter_engine: LatentFilterEngine
    ):
        if not isinstance(monitor_engine, LatentInjectionMonitor):
            raise TypeError("monitor_engine must be an instance of LatentInjectionMonitor.")
        if not isinstance(filter_engine, LatentFilterEngine):
            raise TypeError("filter_engine must be an instance of LatentFilterEngine.")

        self.monitor = monitor_engine
        self.filter = filter_engine
        logger.info("🎯 [sd_tool Coordinator Init] Successfully linked Monitor and Filter Engines.")

    def reset_coordinator_state(self) -> None:
        """إعادة ضبط سجلات المراقب تمهيدًا لبدء دورة توليد جديدة."""
        self.monitor.reset_monitor()
        logger.info("🔄 [sd_tool Coordinator] State reset completed.")

    def process_step(
        self,
        current_step: int,
        total_steps: int,
        latent_tensor: torch.Tensor,
        smoothing_strength: float,
        device: torch.device,
        dtype: torch.dtype
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        إدارة وتنفيذ خطوة معالجة كاملة:
        1. تقييم حالة الـ Latent عبر المراقب وحساب التغاير والانحراف الهيكلي.
        2. تطبيق الفلترة والتنعيم اللحظي عبر الفلتر.
        3. إرجاع الـ Latent المعالج مع تقرير كامل بخصائص الخطوة.
        """
        if not isinstance(latent_tensor, torch.Tensor):
            raise TypeError("latent_tensor must be a valid torch.Tensor.")

        latent_tensor = latent_tensor.to(device=device, dtype=dtype)

        logger.info(
            f"⚙️ [sd_tool Step {current_step}/{total_steps}] "
            f"Processing step | device={device}, dtype={dtype}"
        )

        # 1. تقييم حالة النبضة والتغيير عبر المراقب
        should_inject, pulse_amplitude, metrics = self.monitor.evaluate_pulse_trigger(
            current_step=current_step,
            total_steps=total_steps,
            latent_tensor=latent_tensor,
            device=device,
            dtype=dtype
        )

        # 2. تطبيق الفلترة والتنقية على الـ Latent
        filtered_latent = self.filter.apply_injection_filter(
            latent_tensor=latent_tensor,
            smoothing_strength=smoothing_strength,
            device=device,
            dtype=dtype
        )

        # 3. تجهيز تقرير الخطوة
        execution_report = {
            "current_step": current_step,
            "total_steps": total_steps,
            "should_inject_pulse": should_inject,
            "pulse_amplitude": pulse_amplitude,
            "metrics": metrics
        }

        logger.info(
            f"✅ [sd_tool Step {current_step}] Step completed | "
            f"Trigger={should_inject}, Amplitude={pulse_amplitude:.3f}, "
            f"Variance={metrics['variance']:.4f}"
        )

        return filtered_latent, execution_report


# ==============================================================================
#  تست وحقن تجريبي (Main Execution Entry Point)
# ==============================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running sd_tool Coordinator Integration Test")
    print("=" * 60 + "\n")

    test_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    test_dtype = torch.float32

    # 1. تهيئة الأجزاء صراحة بدون إفتراضات
    monitor_inst = LatentInjectionMonitor(
        entropy_threshold=0.85,
        drift_trigger_sensitivity=0.12,
        max_allowed_variance=3.5,
        pulse_cooldown_steps=1
    )

    filter_inst = LatentFilterEngine(
        blur_kernel_size=3,
        clamp_range=4.0
    )

    # 2. بناء كائن المنسق
    coordinator = SD_tools(
        monitor_engine=monitor_inst,
        filter_engine=filter_inst
    )

    total_steps = 10
    dummy_latent = torch.randn((1, 4, 64, 64), device=test_device, dtype=test_dtype)

    print("Simulating Denoising Loop execution via sd_tool Coordinator...\n")

    for step in range(1, 6):
        # محاكاة تغيّر الـ Latent مع إضافة ضوضاء
        dummy_latent = dummy_latent + torch.randn_like(dummy_latent) * 0.1

        processed_latent, report = coordinator.process_step(
            current_step=step,
            total_steps=total_steps,
            latent_tensor=dummy_latent,
            smoothing_strength=0.08,
            device=test_device,
            dtype=test_dtype
        )

        print(
            f"Result Step {step:02d} | Shape: {processed_latent.shape} | "
            f"Device: {processed_latent.device} | Trigger: {report['should_inject_pulse']} | "
            f"Min: {processed_latent.min():.4f}, Max: {processed_latent.max():.4f}\n"
        )

    print("✅ Integration Test Completed Successfully!")