# sd_latent_monitor.py
"""
محرك مراقبة وتحليل حالة الـ Latent Space (Latent State & Pulse Injection Monitor).
المسؤولية:
1. قياس المؤشرات الإحصائية اللحظية للـ Latent (Entropy, Variance, Mean Energy).
2. تتبع نسبة الانحراف الهيكلي (Structural Drift Rate) بين خطوة وأخرى.
3. إصدار قرار الحقن المتردد (Injection Trigger) مع ضبط معيار القوة الديناميكية (Pulse Amplitude Factor).
4. عزل تام عن خوارزميات التوجيه المباشرة لضمان أحادية المسؤولية.
"""

from __future__ import annotations

import logging
from typing import Dict, Any, Tuple, Union
import torch

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("LATENT_MONITOR")


class LatentInjectionMonitor:
    """محرك المراقبة والتشخيص اللحظي لحلقات الحقن المتردد بداخل الـ Latent Space."""

    def __init__(
        self,
        entropy_threshold: float,
        drift_trigger_sensitivity: float,
        max_allowed_variance: float,
        pulse_cooldown_steps: int
    ):
        if entropy_threshold <= 0 or drift_trigger_sensitivity <= 0 or max_allowed_variance <= 0:
            raise ValueError("All threshold values must be strictly positive.")
        if pulse_cooldown_steps < 0:
            raise ValueError("pulse_cooldown_steps cannot be negative.")

        self.entropy_threshold = entropy_threshold
        self.drift_trigger_sensitivity = drift_trigger_sensitivity
        self.max_allowed_variance = max_allowed_variance
        self.pulse_cooldown_steps = pulse_cooldown_steps
        
        # ذاكرة الحسابات التاريخية للخطوات
        self.previous_latent_snapshot: Union[torch.Tensor, None] = None
        self.last_injected_step: int = -99
        
        logger.info(
            f"📡 [Monitor Init] sensitivity={drift_trigger_sensitivity}, "
            f"max_var={max_allowed_variance}, cooldown={pulse_cooldown_steps}"
        )

    def reset_monitor(self) -> None:
        """إعادة تعيين ذاكرة المراقب مع بداية كل عملية توليد جديدة."""
        self.previous_latent_snapshot = None
        self.last_injected_step = -99
        logger.info("🔄 [Monitor Reset] تم تصفير سجلات المراقبة.")

    def analyze_latent_state(
        self,
        latent_tensor: torch.Tensor,
        device: torch.device,
        dtype: torch.dtype
    ) -> Dict[str, float]:
        """حساب المؤشرات الإحصائية الأساسية لحالة الـ Latent الحالية بشكل صريح."""
        if not isinstance(latent_tensor, torch.Tensor):
            raise TypeError("latent_tensor must be a valid torch.Tensor.")

        detached_latent = latent_tensor.to(device=device, dtype=dtype).detach()
        
        with torch.no_grad():
            mean_val = torch.mean(detached_latent).item()
            variance_val = torch.var(detached_latent).item()
            std_val = torch.std(detached_latent).item()
            energy = (torch.norm(detached_latent, p=2) / detached_latent.numel()).item()
            
            normalized_abs = torch.abs(detached_latent - mean_val) / (std_val + 1e-8)
            pseudo_entropy = torch.mean(normalized_abs).item()

        return {
            "mean": mean_val,
            "variance": variance_val,
            "std": std_val,
            "energy": energy,
            "pseudo_entropy": pseudo_entropy
        }

    def compute_structural_drift(
        self,
        current_latent: torch.Tensor,
        device: torch.device,
        dtype: torch.dtype
    ) -> float:
        """حساب معدل التغير الهيكلي (Structural Drift Rate) مقارنة بالخطوة السابقة."""
        current_latent = current_latent.to(device=device, dtype=dtype)

        if self.previous_latent_snapshot is None:
            self.previous_latent_snapshot = current_latent.detach().clone()
            return 0.0

        with torch.no_grad():
            delta = current_latent.detach() - self.previous_latent_snapshot.to(device=device, dtype=dtype)
            drift_rate = (torch.norm(delta, p=2) / (torch.norm(self.previous_latent_snapshot, p=2) + 1e-8)).item()
            self.previous_latent_snapshot = current_latent.detach().clone()

        return drift_rate

    def evaluate_pulse_trigger(
        self,
        current_step: int,
        total_steps: int,
        latent_tensor: torch.Tensor,
        device: torch.device,
        dtype: torch.dtype
    ) -> Tuple[bool, float, Dict[str, Any]]:
        """
        تقييم شامل لحالة الـ Latent واتخاذ قرار الحقن المتردد بصراحة كاملة.
        """
        if total_steps <= 0 or current_step < 0:
            raise ValueError("current_step and total_steps must be valid positive integers.")

        step_ratio = current_step / float(total_steps)
        metrics = self.analyze_latent_state(latent_tensor, device=device, dtype=dtype)
        drift_rate = self.compute_structural_drift(latent_tensor, device=device, dtype=dtype)
        metrics["drift_rate"] = drift_rate
        metrics["step_ratio"] = step_ratio

        # 1. فحص فترة التبريد (Cooldown Check)
        if (current_step - self.last_injected_step) < self.pulse_cooldown_steps:
            logger.debug(f"⏳ [Monitor Step {current_step}] الحقن في فترة التبريد (Cooldown active).")
            return False, 0.0, metrics

        # 2. فحص مرحلة الاستقرار المتأخرة
        if step_ratio > 0.75:
            logger.debug(f"🛑 [Monitor Step {current_step}] وصلنا للمرحلة المتأخرة (step_ratio > 0.75). توقف الحقن.")
            return False, 0.0, metrics

        # 3. حماية الـ Latent Space من التشوه والتشتت الزائد
        if metrics["variance"] > self.max_allowed_variance:
            logger.warning(
                f"⚠️ [Monitor Step {current_step}] التباين مرتفع جدًا ({metrics['variance']:.3f}). "
                f"تم إلغاء الحقن لحماية الصورة."
            )
            return False, 0.0, metrics

        # 4. شروط تفعيل النبضة الديناميكية
        should_inject = False
        base_amplitude = 1.0

        if drift_rate > self.drift_trigger_sensitivity:
            should_inject = True
            base_amplitude = min(1.5, drift_rate / self.drift_trigger_sensitivity)
            logger.info(f"⚡ [Monitor Step {current_step}] اكتشاف انحراف هيكلي (Drift={drift_rate:.4f}). تفعيل الحقن.")

        elif step_ratio < 0.4 and metrics["pseudo_entropy"] < self.entropy_threshold:
            should_inject = True
            base_amplitude = 1.2
            logger.info(f"🌀 [Monitor Step {current_step}] طاقة الـ Latent منخفضة. تفعيل حقن تعزيز الهيكل.")

        if should_inject:
            damped_amplitude = base_amplitude * max(0.2, (1.0 - step_ratio))
            self.last_injected_step = current_step
            return True, damped_amplitude, metrics

        return False, 0.0, metrics


# ==============================================================================
#  تست وحقن تجريبي (Main Execution Entry Point)
# ==============================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running LatentInjectionMonitor Integration Test")
    print("=" * 60 + "\n")

    test_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    test_dtype = torch.float32

    # تهيئة مراقب الحقن بقيم صريحة بدلاً من الإفتراضيات
    monitor = LatentInjectionMonitor(
        entropy_threshold=0.85,
        drift_trigger_sensitivity=0.12,
        max_allowed_variance=3.5,
        pulse_cooldown_steps=1
    )

    total_steps = 20
    dummy_latent = torch.randn((1, 4, 64, 64), device=test_device, dtype=test_dtype)

    print("Simulating Denoising Loop steps...")

    for step in range(1, 10):
        dummy_latent = dummy_latent + torch.randn_like(dummy_latent) * 0.15
        
        should_inject, amp, metrics = monitor.evaluate_pulse_trigger(
            current_step=step,
            total_steps=total_steps,
            latent_tensor=dummy_latent,
            device=test_device,
            dtype=test_dtype
        )
        
        print(
            f"Step {step:02d}/{total_steps} | Trigger: {should_inject} | "
            f"Amplitude: {amp:.3f} | Variance: {metrics['variance']:.3f} | Drift: {metrics['drift_rate']:.4f}"
        )

    print("\n✅ Self-Test Completed Successfully!")