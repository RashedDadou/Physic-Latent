# canvas_steps_adapter.py

"""
محول ومسقط إحداثيات Canvas 3D إلى مصفوفات Latent Space.
وظيفة الملف حصراً: استقبال السحائب والمتجهات المجردة لإسقاط النقاط والتنقيط (Pure Rasterization).
"""

from __future__ import annotations

import logging
from typing import Union, List, Tuple, Optional
import numpy as np
import torch
import torch.nn.functional as F

# ضبط إعدادات السجل القياسية لتتبع الأداء والعمليات الفيزيائية
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("CANVAS_LATENT_ADAPTER")


class PhysicalEntity3D:
    """كائن يمثل أي شكل/جسم فيزيائي عام بمقاسات وزوايا دوران حقيقية في الفضاء الثلاثي."""

    def __init__(
        self,
        name: str,
        center_xyz: Tuple[float, float, float],
        dimensions_lwh: Tuple[float, float, float],
        rotation_deg: Tuple[float, float, float] = (0.0, 0.0, 0.0),  # (Pitch, Yaw, Roll)
        density_weight: float = 1.0,
        shape_type: str = "box"  # "box" أو "cylinder"
    ):
        self.name = name
        self.center = np.array(center_xyz, dtype=np.float32)
        self.dimensions = np.array(dimensions_lwh, dtype=np.float32)
        self.rotation_deg = np.array(rotation_deg, dtype=np.float32)
        self.density_weight = density_weight
        self.shape_type = shape_type
        
        logger.debug(f"📦 [Entity Init] تم إنشاء الكيان '{self.name}' بالنظام ({self.shape_type}) والأبعاد {self.dimensions}")

    def get_rotation_matrix(self) -> np.ndarray:
        """حساب مصفوفة الدوران الثلاثية بناءً على زوايا Euler (Pitch, Yaw, Roll)
        مع الالتزام بنظام الإحداثيات القياسي (Right-handed convention).
        """
        rad = np.radians(self.rotation_deg)
        rx, ry, rz = rad[0], rad[1], rad[2]

        cx, sx = np.cos(rx), np.sin(rx)
        cy, sy = np.cos(ry), np.sin(ry)
        cz, sz = np.cos(rz), np.sin(rz)

        # Rx: Pitch
        Rx = np.array([
            [1, 0, 0],
            [0, cx, -sx],
            [0, sx, cx]
        ], dtype=np.float32)

        # Ry: Yaw (تعديل الإشارة القياسي للـ Right-handed system)
        Ry = np.array([
            [cy, 0, -sy],
            [0, 1, 0],
            [sy, 0, cy]
        ], dtype=np.float32)

        # Rz: Roll
        Rz = np.array([
            [cz, -sz, 0],
            [sz, cz, 0],
            [0, 0, 1]
        ], dtype=np.float32)

        # ضرب المصفوفات بالترتيب: Yaw (Ry) -> Pitch (Rx) -> Roll (Rz)
        return Rz @ Rx @ Ry

    def generate_point_cloud(self, num_samples: int = 6000) -> np.ndarray:
        """توليد سحابة نقاط مكثفة ومعدّة حجمياً للكيان."""
        R = self.get_rotation_matrix()
        
        if self.shape_type == "cylinder":
            radius = min(self.dimensions[0], self.dimensions[1]) / 2.0
            height = self.dimensions[2]

            num_shell = int(num_samples * 0.6)
            num_z = max(4, int(np.sqrt(num_shell)))
            num_theta = max(8, num_shell // num_z)

            theta = np.linspace(0, 2 * np.pi, num_theta, endpoint=False)
            z_grid = np.linspace(-height / 2.0, height / 2.0, num_z)
            Theta, Z = np.meshgrid(theta, z_grid)
            
            X_shell = radius * np.cos(Theta).flatten()
            Y_shell = radius * np.sin(Theta).flatten()
            Z_shell = Z.flatten()

            num_caps = int(num_samples * 0.4)
            r_cap = radius * np.sqrt(np.random.rand(num_caps))
            theta_cap = 2 * np.pi * np.random.rand(num_caps)
            z_cap = np.random.choice([-height / 2.0, height / 2.0], size=num_caps)

            X_cap = r_cap * np.cos(theta_cap)
            Y_cap = r_cap * np.sin(theta_cap)
            Z_cap = z_cap

            X = np.concatenate([X_shell, X_cap])
            Y = np.concatenate([Y_shell, Y_cap])
            Z = np.concatenate([Z_shell, Z_cap])

            local_points = np.stack([X, Y, Z], axis=-1)
        else:
            pts_per_axis = max(3, int(round(num_samples ** (1.0 / 3.0))))

            dx, dy, dz = self.dimensions / 2.0
            x_pts = np.linspace(-dx, dx, pts_per_axis)
            y_pts = np.linspace(-dy, dy, pts_per_axis)
            z_pts = np.linspace(-dz, dz, pts_per_axis)
            X, Y, Z = np.meshgrid(x_pts, y_pts, z_pts)
            local_points = np.stack([X.flatten(), Y.flatten(), Z.flatten()], axis=-1)

        rotated_points = local_points @ R.T
        world_points = rotated_points + self.center
        logger.debug(f"☁️ [PointCloud] تم توليد {len(world_points)} نقطة للكيان '{self.name}'")
        return world_points


class CanvasLatentAdapter:
    """محول ومعالج تنقيط مجرد (Stateless Transformer/Rasterizer)."""

    def __init__(self):
        logger.info("⚡ [CanvasLatentAdapter] تم تهيئة المحول التنقيطي المجرد (Stateless Adapter).")

    def render_scene_with_camera(
        self,
        entities: List[PhysicalEntity3D],
        grid_shape: Tuple[int, int],
        camera_pos: np.ndarray,
        camera_right: np.ndarray,
        camera_up: np.ndarray,
        camera_forward: np.ndarray,
        focal_length: float
    ) -> Tuple[np.ndarray, np.ndarray]:
        """إسقاط المشهد باستلام البعد البؤري وحساب المعاملات الفردية."""
        focal_pixel = (min(grid_shape) / 2.0) * (focal_length / 1000.0)
        logger.info(f"📸 [Camera Bridge] حساب البؤرة بالبكسل: {focal_pixel:.2f}px (Focal Length: {focal_length}mm)")
        
        return self.render_physical_entities_to_mask(
            entities=entities,
            grid_shape=grid_shape,
            camera_pos=camera_pos,
            camera_right=camera_right,
            camera_up=camera_up,
            camera_forward=camera_forward,
            focal_pixel=focal_pixel
        )

    def render_physical_entities_to_mask(
        self,
        entities: List[PhysicalEntity3D],
        grid_shape: Tuple[int, int],
        camera_pos: np.ndarray,
        camera_right: np.ndarray,
        camera_up: np.ndarray,
        camera_forward: np.ndarray,
        focal_pixel: float
    ) -> Tuple[np.ndarray, np.ndarray]:
        """إسقاط الكائنات بناءً على متجهات نظر ورقم بؤري ممررة مباشرة بدون أي حالة داخلية."""
        h, w = grid_shape
        canvas_grid = np.zeros(grid_shape, dtype=np.float32)
        depth_grid = np.full(grid_shape, fill_value=np.inf, dtype=np.float32)

        logger.info(f"🎨 [Rasterizer] بدء إسقاط المشهد على شبكة أبعادها {grid_shape} | عدد الكائنات: {len(entities)}")

        for entity in entities:
            points_3d = entity.generate_point_cloud(num_samples=6000)
            
            # إسقاط باستخدام المتجهات الممررة مباشرة للدالة
            translated = points_3d - camera_pos
            x_cam = np.dot(translated, camera_right)
            y_cam = np.dot(translated, camera_up)
            z_cam = np.dot(translated, camera_forward)

            valid_mask = z_cam > 0.1
            x_cam = np.atleast_1d(x_cam[valid_mask])
            y_cam = np.atleast_1d(y_cam[valid_mask])
            z_cam = np.atleast_1d(z_cam[valid_mask])

            if z_cam.size == 0:
                logger.warning(f"⚠️ الكيان '{entity.name}' خارج نطاق رؤية الكاميرا بالكامل (Behind Camera).")
                continue

            px = np.atleast_1d(np.int32((x_cam * focal_pixel / z_cam) + (w / 2.0)))
            py = np.atleast_1d(np.int32((-y_cam * focal_pixel / z_cam) + (h / 2.0)))

            inside = (px >= 1) & (px < w - 1) & (py >= 1) & (py < h - 1)
            px = px[inside]
            py = py[inside]
            z_cam = z_cam[inside]

            if z_cam.size == 0:
                logger.warning(f"⚠️ النقاط الملقاة للكيان '{entity.name}' تقع خارج أبعاد شبكة العرض.")
                continue

            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    px_shifted = px + dx
                    py_shifted = py + dy
                    np.maximum.at(canvas_grid, (py_shifted, px_shifted), entity.density_weight)
                    np.minimum.at(depth_grid, (py_shifted, px_shifted), z_cam)

            logger.info(f"📐 [Rasterizer] تم إسقاط '{entity.name}' بنجاح | نطاق العمق: {np.min(z_cam):.2f}m -> {np.max(z_cam):.2f}m")

        # المعالجة المعدلة: تثبيت الـ Far Plane بناءً على أبعاد الغرفة أو أقصى عمق حقيقي
        has_valid_depth = ~np.isinf(depth_grid)
        if np.any(has_valid_depth):
            room_entity = next((e for e in entities if "room" in e.name.lower() or "wall" in e.name.lower()), None)
            
            if room_entity is not None:
                max_room_depth = float(np.linalg.norm(room_entity.center - camera_pos) + np.max(room_entity.dimensions) / 2.0)
                background_far_plane = max_room_depth
                logger.info(f"🌐 [Depth Plane] تم ضبط خلفية المشهد (Far Plane) بناءً على أبعاد الغرفة: {background_far_plane:.2f}m")
            else:
                background_far_plane = float(np.max(depth_grid[has_valid_depth]) + 0.5)
                logger.info(f"🌐 [Depth Plane] عدم العثور على هيكل غرفة، تم الاستناد لأقصى عمق للنقاط: {background_far_plane:.2f}m")

            depth_grid[~has_valid_depth] = background_far_plane
        else:
            depth_grid[:] = 10.0
            logger.warning("⚠️ لا توجد نقاط صحيحة في المشهد، تم تعيين قيمة افتراضية ثابتة للعمق (10.0m)")
        
        return canvas_grid, depth_grid

    @staticmethod
    def convert_grid_to_latent_tensor(
        canvas_grid: np.ndarray, 
        target_latent_shape: Tuple[int, int], 
        device: Optional[Union[str, torch.device]] = None,
        dtype: torch.dtype = torch.float32
    ) -> torch.Tensor:
        """تحويل الشبكة الناتجة إلى Latent Space."""
        if device is None:
            device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        elif isinstance(device, str):
            device = torch.device(device)

        grid_np = np.ascontiguousarray(canvas_grid, dtype=np.float32)
        grid_tensor = torch.from_numpy(grid_np).unsqueeze(0).unsqueeze(0).to(device=device, dtype=dtype)
        
        pooled = F.max_pool2d(grid_tensor, kernel_size=3, stride=1, padding=1)

        latent_mask = F.interpolate(
            pooled, 
            size=target_latent_shape, 
            mode="bilinear", 
            align_corners=False
        )
        
        logger.info(f"🧬 [Latent Conversion] تم تحويل الشبكة إلى Latent Tensor | الشكل المستهدف: {latent_mask.shape} | الجهاز: {device}")
        return latent_mask


# ==============================================================================
# MAIN EXECUTION BLOCK (اختبار صحة الأداء والاستدعاء المباشر)
# ==============================================================================
if __name__ == "__main__":
    logger.info("🚀 [Main Test] بدء تشغيل اختبار الأداء لوحدة CanvasLatentAdapter...")

    # 1. إعداد كيانات فيزيائية وهمية لتمثيل المشهد
    room = PhysicalEntity3D(
        name="Main_Room_Structure",
        center_xyz=(0.0, 0.0, 5.0),
        dimensions_lwh=(10.0, 10.0, 4.0),
        rotation_deg=(0.0, 0.0, 0.0),
        density_weight=0.2,
        shape_type="box"
    )

    obstacle = PhysicalEntity3D(
        name="Central_Cylinder_Pillar",
        center_xyz=(0.0, 0.0, 4.0),
        dimensions_lwh=(1.5, 1.5, 3.0),
        rotation_deg=(0.0, 15.0, 0.0),
        density_weight=1.0,
        shape_type="cylinder"
    )

    scene_entities = [room, obstacle]

    # 2. إعداد المتجهات المطلوبة للكاميرا الوهمية
    cam_pos = np.array([0.0, 0.0, 0.0], dtype=np.float32)
    cam_right = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    cam_up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
    cam_forward = np.array([0.0, 0.0, 1.0], dtype=np.float32)
    focal_length_mm = 35.0
    grid_res = (512, 512)

    # 3. تشغيل المحول وإسقاط النقاط
    adapter = CanvasLatentAdapter()
    canvas_mask, depth_map = adapter.render_scene_with_camera(
        entities=scene_entities,
        grid_shape=grid_res,
        camera_pos=cam_pos,
        camera_right=cam_right,
        camera_up=cam_up,
        camera_forward=cam_forward,
        focal_length=focal_length_mm
    )

    # 4. تحويل النتائج إلى Latent Tensor اختباري
    target_shape = (64, 64)
    latent_tensor = CanvasLatentAdapter.convert_grid_to_latent_tensor(
        canvas_grid=canvas_mask,
        target_latent_shape=target_shape
    )

    logger.info(f"✅ [Main Test Complete] تمت العملية بنجاح!")
    logger.info(f"📊 القيمة القسوى للمقنع: {canvas_mask.max():.2f} | أقصى عمق: {depth_map.max():.2f}m")
    logger.info(f"📐 أبعاد الـ Latent Tensor النهائي: {tuple(latent_tensor.shape)}")