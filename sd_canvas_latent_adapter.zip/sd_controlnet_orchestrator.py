# sd_controlnet_orchestrator.py
"""
المنسق المركزي الموحد (SD ControlNet & Physics Orchestrator).
المسؤولية:
1. التنسيق والربط بين المحركات الثلاثة:
   - CanvasLatentAdapter (الحقن الفيزيائي، الكاميرا، الشبكة، والإضاءة).
   - DenoisingChamberEngine (غرفة التنفيذ الهجينة والغرف الفرعية الموزونة).
   - LatentControlNetEngine (معالجة وتطبيع إشارات ControlNet والتناقص الزمني).
2. استقبال الـ Latent وخطوات الـ Denoising الحالية وتطبيق سيل المعالجة الموحد ببطانة آمنة.
3. توفير واجهة جراحية موحدة (Orchestrated Pipeline API) للتدخل بداخل محركات Stable Diffusion وUNet.
"""

from __future__ import annotations

import logging
import inspect
from typing import Dict, Any, Optional, Tuple, Union, List
import numpy as np
import torch

# استدعاء المحركات والوحدات المنسقة
from sd_canvas_latent_adapter import CanvasLatentAdapter
from sd_denoising_chamber import DenoisingChamberEngine
from sd_latent_controlnet import LatentControlNetEngine

# إعداد نظام التسجيل التفصيلي (Logging)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | [%(name)s] %(message)s"
)
logger = logging.getLogger("CONTROLNET_ORCHESTRATOR")


class SDControlNetOrchestrator:
    """المايسترو الموحد لمنظومة الحقن الفيزيائي، التحكم الهيكلي، والتنعيم الهجين."""

    def __init__(
        self,
        device_input: Union[str, torch.device] = "cuda",
        grid_resolution: Tuple[int, int] = (64, 64),
        target_resolution: Tuple[int, int] = (512, 512),
        default_control_strength: float = 1.0,
        smoothing_strength: float = 0.05,
        clamp_range: float = 4.0
    ):
        if isinstance(device_input, torch.device):
            self.device = device_input
        else:
            self.device = torch.device(device_input if torch.cuda.is_available() else "cpu")

        self.grid_resolution = grid_resolution
        self.target_resolution = target_resolution

        logger.info(
            f"🚀 [Orchestrator Init] Device: {self.device} | Grid: {grid_resolution} | Target: {target_resolution}"
        )

        # 1. تهيئة محرك الحقن الفيزيائي (Canvas Latent Adapter)
        self.physics_adapter = CanvasLatentAdapter(
            device_input=self.device,
            grid_resolution=grid_resolution,
            smoothing_strength=smoothing_strength,
            clamp_range=clamp_range
        )

        # 2. تهيئة غرفة المعالجة الهجينة (Denoising Chamber Engine)
        self.chamber_engine = DenoisingChamberEngine(
            target_resolution=target_resolution
        )

        # 3. تهيئة محرك ControlNet لـ Latent Space
        self.controlnet_engine = LatentControlNetEngine(
            default_strength=default_control_strength
        )

    def reset_orchestrator(self) -> None:
        """إعادة تعيين الحالة الداخلية لجميع المحركات الفرعية."""
        self.physics_adapter.reset_pipeline()
        logger.info("🔄 [Orchestrator Reset] تم إعادة تعيين الحالة والذاكرة لجميع المحركات المنسقة.")

    def orchestrate_denoising_pass(
        self,
        current_latent: torch.Tensor,
        current_step: int,
        total_steps: int,
        control_input: Optional[Union[np.ndarray, torch.Tensor]] = None,
        sub_chambers_config: Optional[List[Dict[str, Any]]] = None,
        cam_dict: Optional[Dict[str, Any]] = None,
        camera_pos: Tuple[float, float, float] = (0.0, 1.5, -5.0),
        light_dir: Tuple[float, float, float] = (0.5, 1.0, -0.5),
        base_injection_strength: float = 0.15,
        control_strength: Optional[float] = None
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        التدفق الموحد الشامل للتنفيذ:
        1. تطبيق الحقن الفيزيائي المحمي عبر CanvasLatentAdapter.
        2. تجهيز وحساب كسب ControlNet عبر LatentControlNetEngine.
        3. دمج الإشارات وتمريرها عبر DenoisingChamberEngine بالتنعيم الحافي للغرف الفرعية.
        """
        logger.info(
            f"🎭 [Orchestrated Pass Start] Step {current_step}/{total_steps} | "
            f"Latent Shape: {current_latent.shape} | Device: {self.device}"
        )

        step_ratio = float(current_step) / float(max(total_steps, 1))
        latent_tensor = current_latent.to(self.device)

        # --- المرحلة الأولى: الحقن الفيزيائي (Physics Adapter Pass) ---
        physically_injected_latent, phys_info = self.physics_adapter.inject_physics_into_latent(
            current_latent=latent_tensor,
            current_step=current_step,
            total_steps=total_steps,
            cam_dict=cam_dict,
            camera_pos=camera_pos,
            light_dir=light_dir,
            base_injection_strength=base_injection_strength
        )

        # --- المرحلة الثانية: معالجة إشارات ControlNet (ControlNet Pass) ---
        spatial_target = (physically_injected_latent.shape[-2], physically_injected_latent.shape[-1])
        
        prepared_control_tensor = self.controlnet_engine.prepare_control_tensor(
            control_input=control_input,
            target_shape=spatial_target,
            device=self.device,
            dtype=physically_injected_latent.dtype
        )

        control_gain_tensor = self.controlnet_engine.compute_control_gain(
            control_tensor=prepared_control_tensor,
            step_ratio=step_ratio,
            strength=control_strength
        )

        # مطابقة القنوات الموجهة مع قنوات الـ Latent
        if control_gain_tensor.shape[1] == 1 and physically_injected_latent.shape[1] > 1:
            expanded_control = control_gain_tensor.repeat(1, physically_injected_latent.shape[1], 1, 1)
        else:
            expanded_control = control_gain_tensor

        # دمج الكسب كـ Delta موزونة بدلاً من الجمع الحاد المؤدي لإشباع الـ Latent
        composite_latent = physically_injected_latent + (expanded_control * 0.1)

        # --- المرحلة الثالثة: معالجة الغرف الفرعية الهجينة (Denoising Chamber Pass) ---
        # بناء قناع حماية فعال ينشط التمرير وتحديث الـ Deltas بدلاً من الحجب الصفري
        if control_gain_tensor.abs().max() > 1e-6:
            valid_mask = (control_gain_tensor.abs() > 1e-6).float()
            if valid_mask.shape[1] == 1 and composite_latent.shape[1] > 1:
                valid_mask = valid_mask.repeat(1, composite_latent.shape[1], 1, 1)
        else:
            valid_mask = torch.ones_like(composite_latent)

        guardrail_payload = {
            "bounded_latent_mask": valid_mask,
            "physics_metrics": phys_info.get("metrics", {})
        }

        final_refined_latent = self.chamber_engine.apply_guarded_denoise_step(
            guardrail_payload=guardrail_payload,
            noise_pred=composite_latent,
            sub_chambers_config=sub_chambers_config,
            step_ratio=step_ratio,
            denoise_strength=base_injection_strength
        )

        # كبح القيم النهائية لمنع الانحراف الإحصائي الحاد
        final_refined_latent = torch.clamp(final_refined_latent, min=-4.0, max=4.0)

        execution_summary = {
            "step": current_step,
            "total_steps": total_steps,
            "step_ratio": step_ratio,
            "physics_info": phys_info,
            "control_peak_gain": float(control_gain_tensor.abs().max().item()),
            "max_latent_amplitude": float(final_refined_latent.abs().max().item())
        }

        logger.info(
            f"✨ [Orchestrated Pass Success] Step {current_step:02d} | "
            f"Control Peak Gain: {execution_summary['control_peak_gain']:.6f} | "
            f"Max Output Amp: {execution_summary['max_latent_amplitude']:.4f}"
        )

        return final_refined_latent, execution_summary


# =============================================================================
# كتلة التشغيل والاختبار الذاتي (Main Execution Guard)
# =============================================================================
if __name__ == "__main__":
    logger.info("=================================================================")
    logger.info("=== بدء الاختبار الذاتي للمنسق الرئيسي (SDControlNetOrchestrator) ===")
    logger.info("=================================================================")

    # 1. تحديد جهاز التجميع والأنماط
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"🖥️ جهاز التشغيل المستهدف للمنسق: {device}")

    # 2. تهيئة المنسق الموحد
    orchestrator = SDControlNetOrchestrator(
        device_input=device,
        grid_resolution=(64, 64),
        target_resolution=(512, 512),
        default_control_strength=0.9
    )

    # 3. إعداد بيانات الاختبار المحاكاة
    total_steps = 10
    batch_size, channels, h, w = 1, 4, 64, 64
    simulated_latent = torch.randn((batch_size, channels, h, w), device=device, dtype=torch.float32)

    # محاكاة إدخال ControlNet (مثل خريطة عمق أو حواف بحجم 256x256)
    mock_controlnet_map = np.random.rand(256, 256).astype(np.float32)

    # إعداد تكوينات الغرف الفرعية الهجينة
    mock_sub_chambers = [
        {
            "refinement_mode": "sharpen_edges",
            "intensity": 1.1,
            "bounds": (0.0, 0.0, 0.5, 0.5)  # الربع العلوِي الأيسر
        },
        {
            "refinement_mode": "smooth_structure",
            "intensity": 0.8,
            "bounds": (0.5, 0.5, 0.5, 0.5)  # الربع السفلي الأيمن
        }
    ]

    # إعداد بيانات الكاميرا والعمق المحاكاة
    mock_cam_dict = {
        "pos": torch.tensor([0.0, 1.5, -5.0], device=device),
        "look_at": torch.tensor([0.0, 0.0, 0.0], device=device),
        "up": torch.tensor([0.0, 1.0, 0.0], device=device),
        "depth_map": torch.rand((1, 1, 64, 64), device=device),
        "canvas_grid": torch.rand((1, 3, 64, 64), device=device)
    }

    orchestrator.reset_orchestrator()

    logger.info("\n🚀 بدء محاكاة حلقة التنسيق الكاملة عبر الخطوات الزمانية...")

    for current_step in range(1, total_steps + 1):
        # محاكاة تطور الإشارة مع إضافة ضوضاء خفيفة
        simulated_latent = simulated_latent * 0.96 + torch.randn_like(simulated_latent) * 0.04

        # استدعاء المنسق لمعالجة الخطوة
        simulated_latent, summary = orchestrator.orchestrate_denoising_pass(
            current_latent=simulated_latent,
            current_step=current_step,
            total_steps=total_steps,
            control_input=mock_controlnet_map,
            sub_chambers_config=mock_sub_chambers,
            cam_dict=mock_cam_dict,
            light_dir=(0.5, 1.0, -0.5),
            base_injection_strength=0.12,
            control_strength=0.85
        )

        logger.info(
            f"📊 [Step {current_step:02d} Summary] "
            f"Injected: {summary['physics_info'].get('injected', False)} | "
            f"Control Gain: {summary['control_peak_gain']:.5f}"
        )

    logger.info("\n📐 اختبار دالة إعادة تحجيم الـ Latent عبر DenoisingChamberEngine...")
    scaled_output = orchestrator.chamber_engine.resize_latent_tensor(
        latents=simulated_latent,
        scale_factor=2.0
    )

    logger.info(f"✨ أبعاد الـ Latent بعد التكبير (2x): {scaled_output.shape}")
    logger.info("=================================================================")
    logger.info("=== اكتملت كافة اختبارات SDControlNetOrchestrator بنجاح تام ===")
    logger.info("=================================================================")