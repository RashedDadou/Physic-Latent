# sd_canvas_latent_adapter.py
"""
المنسق المركزي الموحد (Unified Canvas Latent Adapter) - Strict & Explicit Edition
المسؤولية:
1. التنسيق المباشر والصارم بين المحركات الفيزيائية عبر SD_tools.
2. إلغاء كافة القيم الافتراضية والضميمة (.get with defaults) وتطبيق مبدأ Fail-Fast المباشر.
3. إلزام تمرير كافة معاملات الكاميرا والإضاءة والشبكات المكانية بصراحة.
"""

from __future__ import annotations

import logging
from typing import Dict, Any, Tuple
import torch

from sd_latent_camera import CameraGridCache, LatentCameraWarper
from sd_latent_grid import LatentGridCompositeOrchestrator
from sd_latent_lighting import LatentLightingEngine
from sd_tool import SD_tools

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("CANVAS_LATENT_ADAPTER")


class CanvasLatentAdapter:
    """المايسترو المركزي لربط الفيزياء بـ Latent Space عبر SD_tools بدون افتراضات صامتة."""

    def __init__(
        self,
        sd_tool_engine: SD_tools,
        orchestrator_engine: LatentGridCompositeOrchestrator,
        lighting_engine: LatentLightingEngine,
        device: torch.device,
        dtype: torch.dtype,
        clamp_range: float,
        smoothing_strength: float
    ):
        # التحقق الصارم من الأنماط (Fail-Fast Validation)
        if not isinstance(sd_tool_engine, SD_tools):
            raise TypeError(f"معامل 'sd_tool_engine' يجب أن يكون من كلاس SD_tools، تم استقبال: {type(sd_tool_engine)}")
        if not isinstance(orchestrator_engine, LatentGridCompositeOrchestrator):
            raise TypeError(f"معامل 'orchestrator_engine' يجب أن يكون من نوع LatentGridCompositeOrchestrator")
        if not isinstance(lighting_engine, LatentLightingEngine):
            raise TypeError(f"معامل 'lighting_engine' يجب أن يكون من نوع LatentLightingEngine")
        if not isinstance(device, torch.device):
            raise TypeError(f"معامل 'device' يجب أن يكون من نوع torch.device")
        if not isinstance(dtype, torch.dtype):
            raise TypeError(f"معامل 'dtype' يجب أن يكون من نوع torch.dtype")

        self.sd_tool = sd_tool_engine
        self.grid_orchestrator = orchestrator_engine
        self.lighting_engine = lighting_engine
        self.device = device
        self.dtype = dtype
        self.clamp_range = float(clamp_range)
        self.smoothing_strength = float(smoothing_strength)

        self.camera_cache = CameraGridCache()
        self.warper = LatentCameraWarper()

        logger.info(f"🎨 [CanvasLatentAdapter Strict Init] Pipeline linked without implicit defaults | Device: {self.device}")

    def reset_pipeline(self) -> None:
        """إعادة تعيين حالات المراقب والكاش عبر SD_tools."""
        self.sd_tool.reset_coordinator_state()
        self.camera_cache.clear()
        logger.info("🔄 [Adapter Pipeline] تم إعادة تعيين المنسق والكاش بنجاح.")

    def inject_physics_into_latent(
        self,
        current_latent: torch.Tensor,
        current_step: int,
        total_steps: int,
        camera_data: Dict[str, Any],
        light_config: Dict[str, Any],
        base_injection_strength: float,
        grid_weight: float,
        num_samples_per_line: int
    ) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """
        دالة الحقن المباشرة - تتطلب كافة البيانات المكانية بصراحة وبدون أي قيم افتراضية.
        """
        if current_latent.device != self.device or current_latent.dtype != self.dtype:
            current_latent = current_latent.to(device=self.device, dtype=self.dtype)

        # 1. التحقق الصارم من وجود مفاتيح الكاميرا والشبكات بدون إتاحة fallback صامت
        required_camera_keys = ["pos", "forward", "up", "right", "focal_pixel", "depth_map", "canvas_grid"]
        missing_keys = [k for k in required_camera_keys if k not in camera_data]
        if missing_keys:
            raise KeyError(f"❌ [Strict Check Failed] البيانات الممررة في camera_data تفتقر للمفاتيح المطلوبة: {missing_keys}")

        step_ratio = float(current_step) / float(max(total_steps, 1))

        # 2. تقييم خطوة الـ Denoising وفلترتها عبر SD_tools مباشرة
        filtered_latent, step_report = self.sd_tool.process_step(
            current_step=current_step,
            total_steps=total_steps,
            latent_tensor=current_latent,
            smoothing_strength=self.smoothing_strength,
            device=self.device,
            dtype=self.dtype
        )

        should_inject = step_report["should_inject_pulse"]
        pulse_amplitude = step_report["pulse_amplitude"]
        metrics = step_report["metrics"]

        if not should_inject or pulse_amplitude <= 0.0:
            logger.info(f"⏭️ [Step {current_step:02d}] تجاوز الحقن بناءً على تقرير SD_tools.")
            return filtered_latent, {"injected": False, "step": current_step, "metrics": metrics}

        with torch.no_grad():
            target_shape = filtered_latent.shape
            spatial_shape = (target_shape[2], target_shape[3]) if len(target_shape) == 4 else (target_shape[1], target_shape[2])

            # تجهيز بيانات الكاميرا ونقل التنسورات إلى CPU بصرامة لاستخدامها في حسابات NumPy
            safe_camera_data = {}
            for k, v in camera_data.items():
                if isinstance(v, torch.Tensor):
                    safe_camera_data[k] = v.detach().cpu()
                else:
                    safe_camera_data[k] = v

            # 3. جلب الشبكة المكانية وعمق المشهد - تمرير صريح لكافة المعاملات بدون .get()
            spatial_payload = self.grid_orchestrator.build_complete_spatial_payload(
                latent_shape=spatial_shape,
                camera_dict=safe_camera_data,
                depth_map=camera_data["depth_map"],
                canvas_grid=camera_data["canvas_grid"],
                step_ratio=step_ratio,
                device=self.device,
                dtype=self.dtype,
                focal_pixel=float(camera_data["focal_pixel"]),
                grid_weight=grid_weight,
                num_samples_per_line=num_samples_per_line
            )

            depth_grid_tensor = spatial_payload["depth_grid_tensor"]

            # 4. تطبيق التحويل المنظوري (Camera Warping)
            warped_latent = self.warper.warp_latent_space(
                latents=filtered_latent,
                old_cam_data=camera_data,
                new_cam_data=camera_data,
                depth_map=depth_grid_tensor,
                device=self.device,
                dtype=self.dtype
            )

            # 5. تطبيق تأثير الإضاءة والظلال
            lighting_result = self.lighting_engine.inject_lighting_conditioning(
                latent_tensor=warped_latent,
                depth_tensor=depth_grid_tensor,
                step_ratio=step_ratio,
                light_config=light_config,
                device=self.device,
                dtype=self.dtype
            )

            physics_guarded_latent = lighting_result["guarded_latent"]

            # 6. دمج الشدة وقص القيم
            effective_strength = base_injection_strength * pulse_amplitude
            updated_latent = torch.clamp(physics_guarded_latent, min=-self.clamp_range, max=self.clamp_range)

            logger.info(
                f"💉 [Step {current_step:02d}/{total_steps}] تم الحقن عبر SD_tools | "
                f"Effective Strength: {effective_strength:.4f}"
            )

            execution_info = {
                "injected": True,
                "step": current_step,
                "effective_strength": effective_strength,
                "pulse_amplitude": pulse_amplitude,
                "metrics": metrics
            }

            return updated_latent, execution_info


if __name__ == "__main__":
    logger.info("=== بدء الاختبار الذاتي الصارم لـ CanvasLatentAdapter ===")

    target_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    target_dtype = torch.float32

    from sd_latent_monitor import LatentInjectionMonitor
    from sd_latent_filter import LatentFilterEngine

    # 1. بناء كافة المحركات صراحة وتمرير قيمها بدون الاعتماد على الافتراضات الداخلية
    monitor_inst = LatentInjectionMonitor(
        entropy_threshold=0.85,
        drift_trigger_sensitivity=0.12,
        max_allowed_variance=3.5,
        pulse_cooldown_steps=1
    )
    filter_inst = LatentFilterEngine(
        blur_kernel_size=3,
        clamp_range=4.0
    )
    sd_tool_inst = SD_tools(
        monitor_engine=monitor_inst,
        filter_engine=filter_inst
    )
    orchestrator_inst = LatentGridCompositeOrchestrator(
        mode="1m",
        default_sigma=1.0,
        gain_factor=0.08
    )
    lighting_inst = LatentLightingEngine(intensity_gain=1.2)

    # 2. حقن المحركات صراحة داخل Adapter
    adapter = CanvasLatentAdapter(
        sd_tool_engine=sd_tool_inst,
        orchestrator_engine=orchestrator_inst,
        lighting_engine=lighting_inst,
        device=target_device,
        dtype=target_dtype,
        clamp_range=4.0,
        smoothing_strength=0.05
    )

    adapter.reset_pipeline()

    # 3. تجهيز بيانات اختبار كامة ومكتملة بصرامة (تضمين depth_map و canvas_grid صراحة)
    spatial_shape = (64, 64)
    test_latent = torch.randn((1, 4, 64, 64), device=target_device, dtype=target_dtype)
    test_camera_data = {
        "pos": torch.tensor([0.0, 1.5, -5.0]),
        "forward": torch.tensor([0.0, 0.0, 1.0]),
        "up": torch.tensor([0.0, 1.0, 0.0]),
        "right": torch.tensor([1.0, 0.0, 0.0]),
        "focal_pixel": 600.0,
        "depth_map": torch.ones(spatial_shape, device=target_device, dtype=target_dtype),
        "canvas_grid": torch.zeros(spatial_shape, device=target_device, dtype=target_dtype)
    }
    test_light_config = {
        "type": "directional",
        "direction": (-1.0, -1.0, 0.8),
        "intensity": 1.2
    }

    # 4. تنفيذ خطوة اختبار واحدة مع التمرير الصريح لكافة المعاملات
    out_latent, info = adapter.inject_physics_into_latent(
        current_latent=test_latent,
        current_step=1,
        total_steps=10,
        camera_data=test_camera_data,
        light_config=test_light_config,
        base_injection_strength=0.15,
        grid_weight=0.05,
        num_samples_per_line=250
    )

    logger.info(f"✅ اكتمل الاختبار الصارم بنجاح | Latent Shape: {out_latent.shape} | Injected: {info['injected']}")