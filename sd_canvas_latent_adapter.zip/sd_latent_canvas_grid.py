# sd_latent_canvas_grid.py
"""
محرك معالجة أقنعة الهيكل والأجسام للـ Latent Space (SD Latent Canvas Grid Engine).
المسؤولية: تحويل وتصفية وتنقيط خرائط الأجسام (Canvas Entities) لتقييد حدود الأشكال والخامات.
"""

from __future__ import annotations

import logging
from typing import Tuple, Union
import numpy as np
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("SD_LATENT_CANVAS_GRID")


class LatentCanvasGridEngine:
    """محرك معالجة وتجهيز أقنعة الكائنات والـ Canvas الموجهة للـ Latent Space."""

    def __init__(self, gain_factor: float):
        self.gain_factor = gain_factor
        logger.info(f"Initialized LatentCanvasGridEngine with gain_factor: {self.gain_factor}")

    @staticmethod
    def smooth_canvas_tensor(
        tensor: torch.Tensor,
        kernel_size: int,
        sigma: float
    ) -> torch.Tensor:
        """تنعيم حدود قناع الأجسام لدمجها بمرونة بداخل الـ Latent."""
        channels = tensor.shape[1]
        x = torch.arange(kernel_size, device=tensor.device, dtype=tensor.dtype) - (kernel_size // 2)
        k1d = torch.exp(-0.5 * (x / sigma) ** 2)
        k1d = k1d / k1d.sum()
        k2d = k1d.unsqueeze(1) * k1d.unsqueeze(0)
        kernel = k2d.expand(channels, 1, kernel_size, kernel_size)
        
        smoothed = F.conv2d(tensor, kernel, padding=kernel_size // 2, groups=channels)
        logger.debug(f"Applied Canvas tensor smoothing: shape={tensor.shape}, kernel_size={kernel_size}, sigma={sigma}")
        return smoothed

    def prepare_canvas_tensor(
        self,
        canvas_grid: Union[np.ndarray, torch.Tensor],
        target_shape: Tuple[int, int],
        device: torch.device,
        dtype: torch.dtype
    ) -> torch.Tensor:
        """
        تحويل وتكييف قناع الـ Canvas ليكون بترميز مجالات الـ Latent.
        """
        lh, lw = target_shape

        if isinstance(canvas_grid, np.ndarray):
            tensor = torch.from_numpy(canvas_grid).to(device=device, dtype=dtype)
        elif isinstance(canvas_grid, torch.Tensor):
            tensor = canvas_grid.to(device=device, dtype=dtype)
        else:
            raise TypeError(f"Unsupported canvas_grid type: {type(canvas_grid)}. Expected np.ndarray or torch.Tensor.")

        if tensor.ndim == 2:
            tensor = tensor.unsqueeze(0).unsqueeze(0)
        elif tensor.ndim == 3:
            tensor = tensor.unsqueeze(0)

        if tensor.shape[-2:] != (lh, lw):
            logger.info(f"Resampling canvas tensor from {tuple(tensor.shape[-2:])} to target {target_shape}")
            tensor = F.interpolate(tensor, size=(lh, lw), mode="bilinear", align_corners=False)

        smoothed = self.smooth_canvas_tensor(tensor, kernel_size=3, sigma=0.8)
        result = torch.clamp(smoothed, 0.0, 1.0)
        
        logger.info(f"Canvas tensor prepared successfully: shape={result.shape}, device={device}, dtype={dtype}")
        return result

    def compute_canvas_conditioning_gain(
        self,
        canvas_tensor: torch.Tensor,
        step_ratio: float
    ) -> torch.Tensor:
        """
        حساب مقدار تقييد الهيكل والحدود للأجسام (Canvas Gain) لتقييد ملامح الكائن في المرحلة الثانية.
        """
        decay = max(0.0, 1.0 - step_ratio)
        canvas_gain = canvas_tensor * self.gain_factor * decay
        
        logger.debug(
            f"Computed Canvas Conditioning Gain: step_ratio={step_ratio:.2f}, "
            f"decay={decay:.2f}, max_gain={canvas_gain.max().item():.4f}"
        )
        return canvas_gain