# sd_conditioning_synthesizer.py
"""
وحدة حقن المواد والخصائص البصرية (Material & Surface Conditioning Synthesizer).
الوظيفة: ربط الخامات بالمجسمات مكانياً (Per-Entity Spatial Mapping)
وتوليد خرائط الخامات الموزعة جغرافياً داخل الـ Latent Grid.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Union, List
import numpy as np

# ضبط إعدادات السجل القياسية للوحدة
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("CONDITIONING_SYNTHESIZER")


class MaterialPresets:
    """مكتبة الخامات والمواد الفيزيائية المدمجة (Physical Material Presets)."""
    
    LIBRARY: Dict[str, Dict[str, float]] = {
        "glass": {
            "opacity": 0.85,             # رفع الشفافية الهيكلية للحفاظ على حواف الكأس
            "refractive_index": 1.52,
            "roughness": 0.05,
            "density_weight": 0.9
        },
        "water": {
            "opacity": 0.70,
            "refractive_index": 1.333,
            "roughness": 0.01,
            "density_weight": 0.7
        },
        "metal_chrome": {
            "opacity": 1.0,
            "refractive_index": 2.4,
            "roughness": 0.1,
            "density_weight": 1.0
        },
        "wood_polished": {
            "opacity": 1.0,
            "refractive_index": 1.1,
            "roughness": 0.35,
            "density_weight": 0.85
        },
        "concrete": {
            "opacity": 1.0,
            "refractive_index": 1.0,
            "roughness": 0.9,
            "density_weight": 1.0
        },
        "air_fog": {
            "opacity": 0.15,
            "refractive_index": 1.0003,
            "roughness": 0.0,
            "density_weight": 0.1
        }
    }

    @classmethod
    def get_material(cls, material_name: str) -> Dict[str, float]:
        mat = cls.LIBRARY.get(material_name.lower())
        if mat is None:
            logger.warning(f"⚠️ المادة '{material_name}' غير موجودة بمكتبة Presets. استخدام الإعداد الافتراضي.")
            return {"opacity": 1.0, "refractive_index": 1.0, "roughness": 0.5, "density_weight": 1.0}
        
        logger.debug(f"🧪 [Preset Query] تم جلب خصائص الخامة '{material_name}'")
        return mat.copy()


class ConditioningSynthesizer:
    """محول حقن خامات المواد والخصائص البصرية فوق الأشكال ثلاثية الأبعاد مكانيًا."""

    def __init__(self):
        self.presets = MaterialPresets()
        logger.info("🧪 [Material Synthesizer Init] تم تحميل محرك الخامات المكانية بنجاح.")

    def inject_entity_materials(
        self,
        entities: List[PhysicalEntity3D],
        canvas_grid: np.ndarray,
        material_inputs: Optional[Union[List[str], Dict[str, str]]] = None
    ) -> np.ndarray:
        """
        حقن الخامات مكانياً وفقاً لكل مجسم محدد (Spatial Entity-Material Assignment).
        """
        material_grid = np.zeros_like(canvas_grid, dtype=np.float32)

        if not entities:
            logger.warning("⚠️ لم يتم تعيين أي كيانات فيزيائية لحقن الخامات! إرجاع شبكة القماش الأصلية.")
            return canvas_grid

        logger.info(f"🎨 [Material Mapping] بدء مطابقة وحقن الخامات لـ {len(entities)} كيان(s)...")

        # خريطة الربط بين اسم الكائن وخامته
        mat_map: Dict[str, str] = {}
        if isinstance(material_inputs, dict):
            mat_map = material_inputs
        elif isinstance(material_inputs, list):
            # ربط الترتيب بالتتابع في حال تمرير قائمة
            for i, entity in enumerate(entities):
                if i < len(material_inputs):
                    mat_map[entity.name] = material_inputs[i]

        for entity in entities:
            mat_name = mat_map.get(entity.name, "concrete")
            mat_props = self.presets.get_material(mat_name)

            opacity = mat_props.get("opacity", 1.0)
            ior = mat_props.get("refractive_index", 1.0)

            # معيار الوزن البصري المزدوج (التركيب الهيكلي + معامل الانكسار)
            material_factor = opacity * (1.0 + (ior - 1.0) * 0.15)

            # تطبيق الوزن مكانياً على النطاق المخصص لهذا المجسم فقط
            entity_mask = (canvas_grid >= (entity.density_weight * 0.8))
            material_grid[entity_mask] = canvas_grid[entity_mask] * material_factor

            logger.info(
                f"🎨 [Material Applied] المجسم '{entity.name}' -> الخامة '{mat_name}' "
                f"(Opacity: {opacity:.2f}, IOR: {ior:.2f} -> Factor: {material_factor:.3f})"
            )

        clipped_grid = np.clip(material_grid, 0.0, 1.0)
        logger.info(f"✨ [Material Synthesis] إتمام الحقن المكاني | القيمة القصوى للشبكة المحقونة: {clipped_grid.max():.2f}")
        return clipped_grid

    def build_conditioning_payload(
        self, 
        canvas_grid: np.ndarray,
        latent_mask_tensor: Any,
        entities: Optional[List[PhysicalEntity3D]] = None,
        depth_grid: Optional[np.ndarray] = None,
        material_input: Optional[Union[List[str], Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """تجميع وتصدير حزمة الخامات المكسوّة مكانيًا."""
        logger.info("📦 [Material Payload] بدء تجميع حزمة المواد والخامات المكانية...")
        
        if entities is not None:
            injected_grid = self.inject_entity_materials(entities, canvas_grid, material_input)
        else:
            logger.info("ℹ️ لم تُمرر كيانات مباشرة، سيتم استخدام شبكة Canvas الأصلية في الحزمة.")
            injected_grid = canvas_grid

        payload = {
            "injected_material_grid": injected_grid,
            "depth_grid": depth_grid,
            "latent_mask_tensor": latent_mask_tensor,
            "material_input": material_input
        }
        
        logger.info("✅ [Payload Ready] تم تجهيز حزمة التغذية البصرية والمواد بنجاح.")
        return payload


# ==============================================================================
# MAIN EXECUTION BLOCK (اختبار صحة الأداء والاستدعاء المباشر)
# ==============================================================================
if __name__ == "__main__":
    # استيراد محلي داخل كتلة الاختبار لتفادي التعارض أو الاعتمادية الدائرية
    from canvas_steps_adapter import PhysicalEntity3D, CanvasLatentAdapter

    logger.info("🚀 [Main Test] بدء تشغيل اختبار الأداء لوحدة ConditioningSynthesizer...")

    # 1. إعداد كيانات فيزيائية وهمية
    glass_cup = PhysicalEntity3D(
        name="Glass_Cup",
        center_xyz=(0.0, 0.0, 2.0),
        dimensions_lwh=(0.5, 0.5, 1.0),
        density_weight=0.9,
        shape_type="cylinder"
    )

    chrome_pillar = PhysicalEntity3D(
        name="Chrome_Pillar",
        center_xyz=(1.5, 0.0, 4.0),
        dimensions_lwh=(1.0, 1.0, 3.0),
        density_weight=1.0,
        shape_type="cylinder"
    )

    entities_list = [glass_cup, chrome_pillar]

    # 2. توليد شبكة قماش واختبار محول CanvasLatentAdapter
    adapter = CanvasLatentAdapter()
    cam_pos = np.array([0.0, 0.0, 0.0], dtype=np.float32)
    cam_right = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    cam_up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
    cam_forward = np.array([0.0, 0.0, 1.0], dtype=np.float32)

    canvas, depth = adapter.render_scene_with_camera(
        entities=entities_list,
        grid_shape=(256, 256),
        camera_pos=cam_pos,
        camera_right=cam_right,
        camera_up=cam_up,
        camera_forward=cam_forward,
        focal_length=35.0
    )

    latent_tensor = CanvasLatentAdapter.convert_grid_to_latent_tensor(canvas, (32, 32))

    # 3. إعداد محرك الخامات الموزعة مكانيًا واختبار الحقن
    synthesizer = ConditioningSynthesizer()

    # اختبار الربط باستخدام قاموس (Dictionary)
    materials_dict = {
        "Glass_Cup": "glass",
        "Chrome_Pillar": "metal_chrome"
    }

    payload = synthesizer.build_conditioning_payload(
        canvas_grid=canvas,
        latent_mask_tensor=latent_tensor,
        entities=entities_list,
        depth_grid=depth,
        material_input=materials_dict
    )

    logger.info("📊 [Test Verification] التحقق من نتائج الحزمة الناتجة:")
    logger.info(f"   - أبعاد شبكة الخامات المحقونة: {payload['injected_material_grid'].shape}")
    logger.info(f"   - القيمة القصوى للخامات: {payload['injected_material_grid'].max():.3f}")
    logger.info(f"   - أبعاد Latent Tensor: {tuple(payload['latent_mask_tensor'].shape)}")
    logger.info("✅ [Main Test Complete] تمت العملية بنجاح وبدون أي أخطاء!")