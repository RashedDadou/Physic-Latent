# main_glass.py
import logging
import torch
from camera_engine import Camera3D
from sd_latent_orchestrator import SDLatentOrchestrator

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("MAIN_TEST")


def build_room_table_cup_scene_raw() -> list[dict]:
    return [
        {
            "name": "room_walls",
            "center_xyz": (0.0, 0.0, 0.0),
            "dimensions_lwh": (4.0, 2.8, 4.0),
            "density_weight": 0.2,
            "shape_type": "box"
        },
        {
            "name": "wooden_table",
            "center_xyz": (0.0, -0.5, 0.0),
            "dimensions_lwh": (1.2, 0.8, 0.75),
            "density_weight": 0.85,
            "shape_type": "box"
        },
        {
            "name": "glass_cup",
            "center_xyz": (0.0, -0.085, 0.0),
            "dimensions_lwh": (0.12, 0.08, 0.08),  # أبعاد ممتدة أفقياً لتمثيل السقوط
            "rotation_deg": (0.0, 0.0, 90.0),      # توجيه التدوير إن كان مدعوماً
            "density_weight": 0.4,
            "shape_type": "cylinder"
        }
    ]


def build_material_stack() -> list[str]:
    return ["air_fog", "wood_polished", "glass"]


def main():
    logger.info("⚡ [Main Execution] بدء تشغيل اختبار المنسق الموحد...")

    device = "cuda" if torch.cuda.is_available() else "cpu"

    camera = Camera3D(
        focal_length=1200.0,
        angles_deg=(35.0, 0.0, 0.0),
        distance=2.5,
    )

    scene_entities_raw = build_room_table_cup_scene_raw()
    material_stack = build_material_stack()

    prompt = (
        "a transparent glass cup lying horizontally flat on its side on a polished wooden table, "
        "spilled glass, tipped over sideways, realistic glass refraction and reflections, "
        "warm indoor lighting, photorealistic, highly detailed, 8k resolution"
    )

    negative_prompt = (
        "upright cup, standing glass, vertical cup, floating object, neon green, "
        "oversaturated colors, distorted lighting, bad render, unnatural tint, darkness"
    )

    orchestrator = SDLatentOrchestrator(
        model_id_or_path="runwayml/stable-diffusion-v1-5",
        device_input=device
    )

    # استخراج خصائص الكاميرا ديناميكياً
    cam_pos = getattr(camera, "position", (0.0, 0.0, 2.5))
    cam_fwd = getattr(camera, "forward", (0.0, 0.0, -1.0))
    cam_up = getattr(camera, "up", (0.0, 1.0, 0.0))
    cam_right = getattr(camera, "right", (1.0, 0.0, 0.0))
    focal_length = getattr(camera, "focal_length", 1200.0)

    results = orchestrator.run_simulation_pipeline(
        prompt=prompt,
        negative_prompt=negative_prompt,
        entities=scene_entities_raw,
        material_inputs=material_stack,
        camera_pos=cam_pos,
        camera_forward=cam_fwd,
        camera_up=cam_up,
        camera_right=cam_right,
        focal_length=focal_length,
        num_inference_steps=20,
        guidance_scale=7.5,
        control_strength=0.85,
        seed=42
    )

    # حفظ الصور المخرجة
    rendered_image = results.get("rendered_image") or results.get("image")
    depth_image = results.get("depth_image")

    if rendered_image is not None:
        rendered_image.save("test_room_table_cup_rendered.png")
        logger.info("🖼️ تم حفظ صورة التوليد النهائية: test_room_table_cup_rendered.png")
    else:
        logger.warning("⚠️ لم يتم العثور على صورة للتوليد في قاموس النتائج!")

    if depth_image is not None:
        depth_image.save("test_room_table_cup_depth.png")
        logger.info("🖼️ تم حفظ خريطة العمق: test_room_table_cup_depth.png")
    else:
        logger.warning("⚠️ لم يتم العثور على صورة عمق في قاموس النتائج!")

    logger.info("🎉 [Execution Finished Successfully]")


if __name__ == "__main__":
    main()