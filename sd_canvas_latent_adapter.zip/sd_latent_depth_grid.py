# sd_latent_depth_grid.py
"""
محرك معالجة وتجهيز خرائط العمق للـ Latent Space (SD Latent Depth Grid Engine).
المسؤولية: تحويل، تطبيع، وتنعيم خرائط العمق المنظورية (Depth Maps) وتجهيز موجهاتها للحقن.
"""

from __future__ import annotations

import logging
from typing import Tuple, Union
import numpy as np
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("SD_LATENT_DEPTH_GRID")


class LatentDepthGridEngine:
    """محرك معالجة وحساب خرائط العمق الفيزيائية الموجهة للـ Latent Space."""

    def __init__(self, default_sigma: float):
        self.default_sigma = default_sigma
        logger.info(f"Initialized LatentDepthGridEngine with default_sigma: {self.default_sigma}")

    @staticmethod
    def smooth_depth_tensor(
        tensor: torch.Tensor,
        kernel_size: int,
        sigma: float
    ) -> torch.Tensor:
        """تنعيم قناع العمق لمنع التغيرات المفاجئة أثناء إزالة الضوضاء."""
        channels = tensor.shape[1]
        x = torch.arange(kernel_size, device=tensor.device, dtype=tensor.dtype) - (kernel_size // 2)
        k1d = torch.exp(-0.5 * (x / sigma) ** 2)
        k1d = k1d / k1d.sum()
        k2d = k1d.unsqueeze(1) * k1d.unsqueeze(0)
        kernel = k2d.expand(channels, 1, kernel_size, kernel_size)
        
        smoothed = F.conv2d(tensor, kernel, padding=kernel_size // 2, groups=channels)
        logger.debug(f"Applied Depth tensor smoothing: shape={tensor.shape}, kernel_size={kernel_size}, sigma={sigma}")
        return smoothed

    def prepare_depth_tensor(
        self,
        depth_map: Union[np.ndarray, torch.Tensor],
        target_shape: Tuple[int, int],
        device: torch.device,
        dtype: torch.dtype,
        step_ratio: float
    ) -> torch.Tensor:
        """
        تحويل خريطة العمق القادمة إلى Tensor مطابق للـ Latent Space وتنعيمه بحسب الخطوة الزمنية.
        """
        lh, lw = target_shape

        # 1. التحويل إلى Tensor
        if isinstance(depth_map, np.ndarray):
            tensor = torch.from_numpy(depth_map).to(device=device, dtype=dtype)
        elif isinstance(depth_map, torch.Tensor):
            tensor = depth_map.to(device=device, dtype=dtype)
        else:
            raise TypeError(f"Unsupported depth_map type: {type(depth_map)}. Expected np.ndarray or torch.Tensor.")

        # 2. ضبط الأبعاد إلى 4D (Batch, Channel, Height, Width)
        if tensor.ndim == 2:
            tensor = tensor.unsqueeze(0).unsqueeze(0)
        elif tensor.ndim == 3:
            tensor = tensor.unsqueeze(0)

        # 3. تعديل الحجم إن لم يكن مطابقاً لأبعاد الـ Latent
        if tensor.shape[-2:] != (lh, lw):
            logger.info(f"Interpolating depth tensor from {tuple(tensor.shape[-2:])} to target {target_shape}")
            tensor = F.interpolate(tensor, size=(lh, lw), mode="bilinear", align_corners=False)

        # 4. التنعيم التكيفي بناءً على تقدم الـ Denoising
        if step_ratio <= 0.3:
            logger.debug(f"Early Denoising Phase (step_ratio={step_ratio:.2f}): Applying heavy dilation & smoothing (kernel=5, sigma=1.5)")
            dilated = F.max_pool2d(tensor, kernel_size=5, stride=1, padding=2)
            smoothed = self.smooth_depth_tensor(dilated, kernel_size=5, sigma=1.5)
        else:
            logger.debug(f"Late Denoising Phase (step_ratio={step_ratio:.2f}): Applying light dilation & smoothing (kernel=3, sigma=1.0)")
            dilated = F.max_pool2d(tensor, kernel_size=3, stride=1, padding=1)
            smoothed = self.smooth_depth_tensor(dilated, kernel_size=3, sigma=1.0)

        logger.info(f"Depth tensor prepared successfully: shape={smoothed.shape}, device={device}, dtype={dtype}")
        return smoothed

    def compute_depth_conditioning_mask(
        self,
        depth_tensor: torch.Tensor,
        step_ratio: float,
        strictness_factor: float
    ) -> torch.Tensor:
        """تطبيع العمق وحساب خريطة وزن الحقن الزمني الموجهة للمرحلة الأولى."""
        d_min, d_max = torch.min(depth_tensor), torch.max(depth_tensor)
        depth_range = d_max - d_min

        if depth_range > 1e-4:
            depth_normalized = (depth_tensor - d_min) / (depth_range + 1e-8)
        else:
            logger.debug("Depth tensor range near zero. Returning zeros for normalized depth.")
            depth_normalized = torch.zeros_like(depth_tensor)

        early_enforcement_factor = 2.5 if step_ratio <= 0.3 else 1.0
        temporal_weight = max(0.0, 1.0 - (step_ratio / 0.6)) ** 2

        conditioning_mask = depth_normalized * temporal_weight * strictness_factor * early_enforcement_factor
        
        logger.debug(
            f"Computed Depth Conditioning Mask: step_ratio={step_ratio:.2f}, "
            f"temporal_weight={temporal_weight:.4f}, max_weight={conditioning_mask.max().item():.4f}"
        )
        return conditioning_mask