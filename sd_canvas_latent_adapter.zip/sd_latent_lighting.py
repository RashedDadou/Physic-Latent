# sd_latent_lighting.py
"""
محرك الإضاءة والظلال الثلاثية الأبعاد للـ Latent Space (SD Latent Lighting Engine).
المسؤولية: حساب وتوليد خرائط الإضاءة (الموجهة والعامة) وإسقاط الظلال (Shadow Casting)，
ثم حقنها في الـ Latent Tensor كالمرحلة الثالثة والأخيرة في حلقة الـ Denoising.
"""

from __future__ import annotations

import logging
from typing import Dict, Any, Tuple
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("SD_LATENT_LIGHTING")


class LatentLightingEngine:
    """محرك حساب وإسقاط حقن الإضاءة والظلال على مستوى الـ Latent."""

    def __init__(self, intensity_gain: float):
        if intensity_gain <= 0:
            raise ValueError(f"intensity_gain must be positive, got {intensity_gain}")
        self.intensity_gain = intensity_gain
        logger.info(f"Initialized LatentLightingEngine with intensity_gain: {self.intensity_gain}")

    @staticmethod
    def _smooth_tensor(tensor: torch.Tensor, kernel_size: int, sigma: float) -> torch.Tensor:
        """تنعيم غوسي مخصص للـ Tensors لتفادي التغيرات الحادة في قيم الـ Latent."""
        channels = tensor.shape[1]
        x = torch.arange(kernel_size, device=tensor.device, dtype=tensor.dtype) - (kernel_size // 2)
        k1d = torch.exp(-0.5 * (x / sigma) ** 2)
        k1d = k1d / k1d.sum()
        k2d = k1d.unsqueeze(1) * k1d.unsqueeze(0)
        kernel = k2d.expand(channels, 1, kernel_size, kernel_size)
        
        smoothed = F.conv2d(tensor, kernel, padding=kernel_size // 2, groups=channels)
        logger.debug(f"Applied Lighting tensor smoothing: shape={tensor.shape}, kernel_size={kernel_size}, sigma={sigma}")
        return smoothed

    def calculate_lighting_and_shadow_map(
        self,
        depth_tensor: torch.Tensor,
        light_type: str,
        light_direction: Tuple[float, float, float],
        light_intensity: float,
        shadow_softness: float,
        shadow_length_factor: float,
        device: torch.device,
        dtype: torch.dtype
    ) -> Dict[str, torch.Tensor]:
        """
        حساب خريطة الإضاءة والظلال باستخدام PyTorch Tensors مباشرة وبشكل صريح.
        """
        if depth_tensor.ndim != 4:
            raise ValueError(f"depth_tensor must be 4D [B, C, H, W], got shape {depth_tensor.shape}")

        depth_tensor = depth_tensor.to(device=device, dtype=dtype)
        _, _, h, w = depth_tensor.shape

        light_map = torch.full((1, 1, h, w), 0.5 if light_type == "directional" else 1.0, device=device, dtype=dtype)
        shadow_map = torch.zeros((1, 1, h, w), device=device, dtype=dtype)

        if light_type == "ambient":
            logger.debug("Calculating Ambient Lighting Map (No Directional Shadows).")
            light_map *= light_intensity
            clamped_light = torch.clamp(light_map, 0.0, 1.0)
            return {
                "light_map": clamped_light,
                "shadow_map": shadow_map,
                "combined_lighting_grid": clamped_light
            }

        elif light_type == "directional":
            logger.debug(f"Calculating Directional Lighting & Shadows | light_dir={light_direction}, intensity={light_intensity}")
            
            # 1. تطبيع متجه اتجاه الضوء
            l_dir = torch.tensor(light_direction, device=device, dtype=dtype)
            l_norm = torch.norm(l_dir)
            if l_norm < 1e-6:
                raise ValueError("light_direction vector length cannot be zero.")
            l_dir = l_dir / l_norm

            # 2. حساب المائلات السطحية (Surface Normals)
            kx = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], device=device, dtype=dtype).unsqueeze(0).unsqueeze(0) / 8.0
            ky = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], device=device, dtype=dtype).unsqueeze(0).unsqueeze(0) / 8.0

            gx = F.conv2d(depth_tensor, kx, padding=1)
            gy = F.conv2d(depth_tensor, ky, padding=1)

            normal_z = 1.0 / torch.sqrt(gx**2 + gy**2 + 1.0)
            normal_x = -gx * normal_z
            normal_y = -gy * normal_z

            # 3. حساب الضوء المباشر (Lambertian Reflection)
            dot_product = normal_x * l_dir[0] + normal_y * l_dir[1] + normal_z * l_dir[2]
            direct_light = torch.clamp(dot_product, min=0.0) * light_intensity
            light_map = light_map + direct_light

            # 4. محاكاة إسقاط الظلال
            shift_x = -l_dir[0].item() * shadow_length_factor * 2.0
            shift_y = -l_dir[1].item() * shadow_length_factor * 2.0

            non_zero_depth = (depth_tensor > 0.05).to(dtype=dtype)

            theta = torch.tensor([
                [1.0, 0.0, shift_x],
                [0.0, 1.0, shift_y]
            ], device=device, dtype=dtype).unsqueeze(0)

            grid = F.affine_grid(theta, non_zero_depth.size(), align_corners=False)
            cast_shadow = F.grid_sample(non_zero_depth, grid, mode='bilinear', padding_mode='reflection', align_corners=False)

            cast_shadow = torch.clamp(cast_shadow - non_zero_depth, min=0.0)
            shadow_map = self._smooth_tensor(cast_shadow, kernel_size=5, sigma=shadow_softness)

            combined = torch.clamp(light_map - (shadow_map * 0.7), 0.0, 2.0)

            return {
                "light_map": torch.clamp(light_map, 0.0, 1.0),
                "shadow_map": torch.clamp(shadow_map, 0.0, 1.0),
                "combined_lighting_grid": combined
            }
        else:
            raise ValueError(f"Unsupported light_type: '{light_type}'. Allowed types are 'directional' or 'ambient'.")

    def inject_lighting_conditioning(
        self,
        latent_tensor: torch.Tensor,
        depth_tensor: torch.Tensor,
        step_ratio: float,
        light_config: Dict[str, Any],
        device: torch.device,
        dtype: torch.dtype
    ) -> Dict[str, torch.Tensor]:
        """
        حقن تأثير الإضاءة والظلال مباشرة على الـ Latent Tensor في المرحلة الأخيرة.
        """
        if not isinstance(latent_tensor, torch.Tensor) or not isinstance(depth_tensor, torch.Tensor):
            raise TypeError("Both latent_tensor and depth_tensor must be torch.Tensor instances.")

        latent_tensor = latent_tensor.to(device=device, dtype=dtype)
        depth_tensor = depth_tensor.to(device=device, dtype=dtype)
        lh, lw = latent_tensor.shape[-2], latent_tensor.shape[-1]

        logger.info(f"Injecting lighting conditioning | step_ratio={step_ratio:.2f}, target_shape=({lh}, {lw}), device={device}")

        # 1. التحقق واستخلاص الإعدادات الصريحة
        if "type" not in light_config or "direction" not in light_config or "intensity" not in light_config:
            raise ValueError("light_config must explicitly contain 'type', 'direction', and 'intensity' keys.")

        l_type = light_config["type"]
        l_dir = light_config["direction"]
        l_intensity = light_config["intensity"]

        # 2. ضبط أبعاد depth_tensor
        if depth_tensor.ndim == 2:
            depth_tensor = depth_tensor.unsqueeze(0).unsqueeze(0)
        elif depth_tensor.ndim == 3:
            depth_tensor = depth_tensor.unsqueeze(0)

        if depth_tensor.shape[-2:] != (lh, lw):
            logger.info(f"Resampling depth_grid for lighting from {tuple(depth_tensor.shape[-2:])} to ({lh}, {lw})")
            depth_tensor = F.interpolate(depth_tensor, size=(lh, lw), mode="bilinear", align_corners=False)

        # 3. حساب شبكة الضوء والظل
        lighting_res = self.calculate_lighting_and_shadow_map(
            depth_tensor=depth_tensor,
            light_type=l_type,
            light_direction=l_dir,
            light_intensity=l_intensity,
            shadow_softness=1.2,
            shadow_length_factor=0.35,
            device=device,
            dtype=dtype
        )

        combined_grid = lighting_res["combined_lighting_grid"]
        smoothed_lighting = self._smooth_tensor(combined_grid, kernel_size=3, sigma=0.8)

        # 4. التوهين الزمني للحقن (Decay Factor)
        temporal_factor = max(0.0, 1.0 - abs(step_ratio - 0.4) / 0.6)
        
        # 5. الحقن النهائي
        lighting_gain = (smoothed_lighting - 0.5) * 0.15 * temporal_factor * self.intensity_gain
        guarded_latent = latent_tensor * (1.0 + lighting_gain)
        guarded_latent = torch.clamp(guarded_latent, min=-4.0, max=4.0)

        logger.info(
            f"Lighting injected successfully | temporal_factor={temporal_factor:.4f}, "
            f"max_lighting={smoothed_lighting.max().item():.4f}, max_shadow={lighting_res['shadow_map'].max().item():.4f}"
        )

        return {
            "guarded_latent": guarded_latent,
            "lighting_mask_tensor": smoothed_lighting,
            "shadow_map_tensor": lighting_res["shadow_map"]
        }


# ==============================================================================
#  تست وحقن تجريبي (Main Execution Entry Point)
# ==============================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running LatentLightingEngine Integration Test")
    print("=" * 60 + "\n")

    # 1. الأبعاد وسياق التنفيذ
    lh, lw = 64, 64
    test_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    test_dtype = torch.float32

    # 2. تهيئة محرك الإضاءة
    lighting_engine = LatentLightingEngine(intensity_gain=1.2)

    # 3. إنشاء Latent Tensor و Depth Tensor
    dummy_latent = torch.randn((1, 4, lh, lw), device=test_device, dtype=test_dtype)
    
    y, x = torch.meshgrid(torch.linspace(-1, 1, lh, device=test_device), torch.linspace(-1, 1, lw, device=test_device), indexing="ij")
    dist = torch.sqrt(x**2 + y**2)
    dummy_depth = torch.clamp(1.0 - dist, min=0.0).unsqueeze(0).unsqueeze(0).to(dtype=test_dtype)

    # 4. إعدادات الإضاءة الموجهة صراحة
    explicit_light_config = {
        "type": "directional",
        "direction": (-1.0, -1.0, 0.8),
        "intensity": 1.2
    }

    # 5. اختبار الحقن
    try:
        result = lighting_engine.inject_lighting_conditioning(
            latent_tensor=dummy_latent,
            depth_tensor=dummy_depth,
            step_ratio=0.4,
            light_config=explicit_light_config,
            device=test_device,
            dtype=test_dtype
        )

        print("✅ Execution Successful! Returned Lighting Tensors:")
        for key, tensor in result.items():
            print(f"  - {key}: shape={tensor.shape}, device={tensor.device}, dtype={tensor.dtype}, min={tensor.min():.4f}, max={tensor.max():.4f}")

    except Exception as e:
        print(f"❌ Test Failed with Error: {e}")