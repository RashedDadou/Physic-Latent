# sd_latent_grid.py
"""
محرك شبكات الإحداثيات والعمق والهياكل (Unified Latent Grid Pipeline) - النسخة الصارمة (Strict & Explicit).
المسؤولية:
1. الشبكة الأرضية الثلاثية الأبعاد (3D Ground Grid) بدون افتراضات أو مسارات احترازية.
2. شبكة العمق والمنظور (Depth Grid) عبر استدعاء sd_latent_depth_grid.
3. شبكة الأجسام والهيكل (Canvas Grid) عبر استدعاء sd_latent_canvas_grid.
"""

from __future__ import annotations

import logging
from typing import Tuple, Dict, Any, List, Union
import numpy as np
import torch
import torch.nn.functional as F

from sd_latent_depth_grid import LatentDepthGridEngine
from sd_latent_canvas_grid import LatentCanvasGridEngine

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("SD_LATENT_GRID")


class GroundGridGuardrail:
    """محرك توليد شبكة Grid أرضية ثنائية المقياس للأنظمة الثلاثية الأبعاد."""

    GRID_CONFIGS = {
        "1m": {
            "extent": 1.0,
            "step": 0.1,
            "subdivisions": 10,
            "label": "1 Meter Grid (10cm steps)"
        },
        "10m": {
            "extent": 10.0,
            "step": 1.0,
            "subdivisions": 10,
            "label": "10 Meter Grid (1m steps)"
        }
    }

    def __init__(self, mode: str):
        self.set_mode(mode)
        logger.info(f"Initialized GroundGridGuardrail in '{self.active_mode}' mode.")

    def set_mode(self, mode: str):
        if mode not in self.GRID_CONFIGS:
            logger.error(f"Failed to set invalid mode '{mode}'. Supported modes: {list(self.GRID_CONFIGS.keys())}")
            raise ValueError(f"النمط '{mode}' غير مدعوم. اختر بين '1m' أو '10m'.")

        self.active_mode = mode
        self.config = self.GRID_CONFIGS[mode]
        self.grid_lines = self._generate_grid_vectors()

    def _generate_grid_vectors(self) -> List[Dict[str, Any]]:
        extent = self.config["extent"]
        step = self.config["step"]
        half_extent = extent / 2.0
        ticks = np.arange(-half_extent, half_extent + step, step)

        lines = []
        for z in ticks:
            lines.append({
                "start": np.array([-half_extent, 0.0, z], dtype=np.float32),
                "end": np.array([half_extent, 0.0, z], dtype=np.float32),
                "type": "major" if np.isclose(z, 0.0) else "minor"
            })

        for x in ticks:
            lines.append({
                "start": np.array([x, 0.0, -half_extent], dtype=np.float32),
                "end": np.array([x, 0.0, half_extent], dtype=np.float32),
                "type": "major" if np.isclose(x, 0.0) else "minor"
            })

        return lines

    def get_grid_data(self) -> Dict[str, Any]:
        return {
            "mode": self.active_mode,
            "extent": self.config["extent"],
            "step": self.config["step"],
            "lines": self.grid_lines
        }

    @staticmethod
    def generate_ground_grid_mask(
        latent_shape: Tuple[int, int],
        grid_engine: GroundGridGuardrail,
        camera_data: Dict[str, Any],
        focal_pixel: float,
        grid_weight: float,
        num_samples_per_line: int
    ) -> np.ndarray:

        # 1. التحقق الصارم المباشر من وجود المفاتيح الموحدة المطلوبة
        required_keys = ["pos", "right", "up", "forward"]
        missing_keys = [k for k in required_keys if k not in camera_data]
        if missing_keys:
            raise KeyError(f"❌ [GroundGrid Fail-Fast] camera_data تفتقر للمفاتيح المطلوبة: {missing_keys}")

        h, w = latent_shape
        mask = np.zeros(latent_shape, dtype=np.float32)

        # استخراج القيم المباشرة بدون أغطية أفقية أوget صامت
        c_pos = camera_data["pos"]
        c_right = camera_data["right"]
        c_up = camera_data["up"]
        c_fwd = camera_data["forward"]

        # التحويل الصريح لـ NumPy وإسقاط التنسورات من GPU إن وجدت
        if isinstance(c_pos, torch.Tensor):
            c_pos = c_pos.detach().cpu().numpy()
        if isinstance(c_right, torch.Tensor):
            c_right = c_right.detach().cpu().numpy()
        if isinstance(c_up, torch.Tensor):
            c_up = c_up.detach().cpu().numpy()
        if isinstance(c_fwd, torch.Tensor):
            c_fwd = c_fwd.detach().cpu().numpy()

        grid_data = grid_engine.get_grid_data()
        lines = grid_data["lines"]

        sampled_points_list = []
        weight_factors = []

        for line in lines:
            start_pt = line["start"]
            end_pt = line["end"]
            w_mult = 1.8 if line["type"] == "major" else 1.0

            t_vals = np.linspace(0.0, 1.0, num_samples_per_line, dtype=np.float32)
            line_pts = start_pt[None, :] + t_vals[:, None] * (end_pt - start_pt)[None, :]

            sampled_points_list.append(line_pts)
            weight_factors.append(np.full(num_samples_per_line, grid_weight * w_mult, dtype=np.float32))

        all_grid_pts = np.concatenate(sampled_points_list, axis=0)
        all_weights = np.concatenate(weight_factors, axis=0)

        translated = all_grid_pts - c_pos
        x_cam = np.dot(translated, c_right)
        y_cam = np.dot(translated, c_up)
        z_cam = np.dot(translated, c_fwd)

        valid = z_cam > 1e-4
        x_cam, y_cam, z_cam, all_weights = x_cam[valid], y_cam[valid], z_cam[valid], all_weights[valid]

        if z_cam.size == 0:
            logger.debug("No grid points projected in front of the camera.")
            return mask

        px = np.floor((x_cam * focal_pixel / z_cam) + (w / 2.0)).astype(np.int32)
        py = np.floor((-y_cam * focal_pixel / z_cam) + (h / 2.0)).astype(np.int32)

        inside = (px >= 0) & (px < w) & (py >= 0) & (py < h)

        px_valid = px[inside]
        py_valid = py[inside]
        weights_valid = all_weights[inside]

        if px_valid.size > 0:
            np.maximum.at(mask, (py_valid, px_valid), weights_valid)

        mask_tensor = torch.from_numpy(mask).unsqueeze(0).unsqueeze(0)
        k = torch.tensor([[0.05, 0.1, 0.05], [0.1, 0.4, 0.1], [0.05, 0.1, 0.05]], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        smoothed_tensor = F.conv2d(mask_tensor, k, padding=1)

        result = torch.clamp(smoothed_tensor.squeeze(), 0.0, 1.0).numpy()
        return result


class LatentGridCompositeOrchestrator:
    """
    🔗 المُجامع الموحد (Unified Facade Layer).
    يجمع المحركات الثلاثة (Ground Grid, Depth Grid, Canvas Grid) بدون أي قيم صامتة.
    """

    def __init__(self, mode: str, default_sigma: float, gain_factor: float):
        logger.info(f"Initializing LatentGridCompositeOrchestrator (mode='{mode}')...")
        self.ground_engine = GroundGridGuardrail(mode=mode)
        self.depth_engine = LatentDepthGridEngine(default_sigma=default_sigma)
        self.canvas_engine = LatentCanvasGridEngine(gain_factor=gain_factor)
        logger.info("LatentGridCompositeOrchestrator successfully initialized with all sub-engines.")

    def build_complete_spatial_payload(
        self,
        latent_shape: Tuple[int, int],
        camera_dict: Dict[str, Any],
        depth_map: Union[np.ndarray, torch.Tensor],
        canvas_grid: Union[np.ndarray, torch.Tensor],
        step_ratio: float,
        device: torch.device,
        dtype: torch.dtype,
        focal_pixel: float,
        grid_weight: float,
        num_samples_per_line: int
    ) -> Dict[str, torch.Tensor]:

        logger.info(
            f"Building spatial payload | target_shape={latent_shape}, step_ratio={step_ratio:.2f}, "
            f"device={device}, dtype={dtype}"
        )

        # 1. الأرضية (Ground Grid Mask)
        ground_mask_np = GroundGridGuardrail.generate_ground_grid_mask(
            latent_shape=latent_shape,
            grid_engine=self.ground_engine,
            camera_data=camera_dict,
            focal_pixel=focal_pixel,
            grid_weight=grid_weight,
            num_samples_per_line=num_samples_per_line
        )
        ground_tensor = torch.from_numpy(ground_mask_np).to(device=device, dtype=dtype).unsqueeze(0).unsqueeze(0)

        # 2. العمق والمنظور (Depth Grid Tensor)
        depth_tensor = self.depth_engine.prepare_depth_tensor(
            depth_map=depth_map,
            target_shape=latent_shape,
            device=device,
            dtype=dtype,
            step_ratio=step_ratio
        )

        # 3. الأجسام والـ Canvas (Canvas Grid Tensor)
        canvas_tensor = self.canvas_engine.prepare_canvas_tensor(
            canvas_grid=canvas_grid,
            target_shape=latent_shape,
            device=device,
            dtype=dtype
        )

        logger.info("Spatial payload build complete for all 3 grid layers.")
        return {
            "ground_grid_tensor": ground_tensor,
            "depth_grid_tensor": depth_tensor,
            "canvas_grid_tensor": canvas_tensor
        }


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running LatentGridCompositeOrchestrator Strict Integration Test")
    print("=" * 60 + "\n")

    latent_h, latent_w = 64, 64
    target_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    target_dtype = torch.float32

    # بيانات الكاميرا المكتملة بدون أي حقول ناقصة
    dummy_camera_dict = {
        "pos": np.array([0.0, 1.5, -3.0], dtype=np.float32),
        "forward": np.array([0.0, 0.0, 1.0], dtype=np.float32),
        "up": np.array([0.0, 1.0, 0.0], dtype=np.float32),
        "right": np.array([1.0, 0.0, 0.0], dtype=np.float32),
        "focal_pixel": 600.0
    }

    dummy_depth_map = np.random.uniform(0.5, 5.0, size=(latent_h, latent_w)).astype(np.float32)
    dummy_canvas_grid = np.random.uniform(0.0, 1.0, size=(latent_h, latent_w)).astype(np.float32)

    orchestrator = LatentGridCompositeOrchestrator(
        mode="1m",
        default_sigma=1.0,
        gain_factor=0.08
    )

    try:
        payload = orchestrator.build_complete_spatial_payload(
            latent_shape=(latent_h, latent_w),
            camera_dict=dummy_camera_dict,
            depth_map=dummy_depth_map,
            canvas_grid=dummy_canvas_grid,
            step_ratio=0.15,
            device=target_device,
            dtype=target_dtype,
            focal_pixel=600.0,
            grid_weight=0.05,
            num_samples_per_line=250
        )

        print("\n✅ Strict Test Passed Successfully!")
        for key, tensor in payload.items():
            print(f"  - {key}: shape={tensor.shape}, device={tensor.device}, dtype={tensor.dtype}")

    except Exception as e:
        print(f"\n❌ Test Failed as expected on invalid data: {e}")