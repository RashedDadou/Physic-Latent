# sd_denoising_chamber.py

"""
محرك المعالجة والـ Denoising الهجين غير المقيد (Dynamic Agnostic Sub-Chamber Engine).
المسؤولية: تطبيق معالجة نسيجية ديناميكية ومجهزة بـ Spatial Feathering على أي نطاق مكاني
بناءً على معاملات هجينة تصل من الـ Depth والـ Grid دون حدوث Seam Artifacts.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Tuple, Optional, List
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("DENOISING_CHAMBER_ENGINE")


class DenoisingChamberEngine:
    """غرفة التنفيذ الحسابية الهجينة للمجالات غير المعروفة."""

    def __init__(self, target_resolution: Tuple[int, int] = (512, 512)):
        self.target_resolution = target_resolution
        logger.info(f"⚙️ [Dynamic Chamber Init] جاهز للتطبيق الهجين بأبعاد target={target_resolution}")

    def transform_bounds_to_latent_coords(
        self, 
        normalized_bounds: Tuple[float, float, float, float], 
        latent_height: int, 
        latent_width: int
    ) -> Tuple[int, int, int, int]:
        """تحويل خطي آمن للإحداثيات المطبقة (0.0 -> 1.0) إلى شبكة الـ Latent Grid."""
        logger.debug(
            f"📐 [Transform Bounds] Bounds: {normalized_bounds} | Latent Size: {latent_width}x{latent_height}"
        )
        x_norm, y_norm, w_norm, h_norm = normalized_bounds
        
        x1 = max(0, int(x_norm * latent_width))
        y1 = max(0, int(y_norm * latent_height))
        x2 = min(latent_width, max(x1 + 1, int((x_norm + w_norm) * latent_width)))
        y2 = min(latent_height, max(y1 + 1, int((y_norm + h_norm) * latent_height)))

        logger.info(f"🎯 [Transform Bounds Result] Coords -> x1:{x1}, y1:{y1}, x2:{x2}, y2:{y2}")
        return x1, y1, x2, y2

    def _create_feathered_mask(
        self, 
        height: int, 
        width: int, 
        feather_radius: int = 2, 
        device: torch.device = torch.device("cpu"), 
        dtype: torch.dtype = torch.float32
    ) -> torch.Tensor:
        """توليد قناع مزج ناعم (Feathering Mask) لمنع خطوط القص الحادة عند حدود الغرفة."""
        logger.debug(
            f"🪶 [Create Feather Mask] H:{height}, W:{width}, Radius:{feather_radius}, Device:{device}"
        )
        mask = torch.ones((1, 1, height, width), device=device, dtype=dtype)
        if height <= 2 * feather_radius or width <= 2 * feather_radius:
            logger.warning(
                f"⚠️ [Feathering Skipped] الأبعاد ({height}x{width}) صغيرة جداً بالنسبة لـ Radius ({feather_radius}). إرجاع قناع أُحادي."
            )
            return mask

        # تطبيق التدرج على الحواف
        for i in range(feather_radius):
            scale = (i + 1) / (feather_radius + 1)
            mask[:, :, i, :] *= scale
            mask[:, :, height - 1 - i, :] *= scale
            mask[:, :, :, i] *= scale
            mask[:, :, :, width - 1 - i] *= scale

        logger.info(f"✅ [Feather Mask Created] Shape: {mask.shape} | Min: {mask.min().item():.3f}, Max: {mask.max().item():.3f}")
        return mask

    def process_dynamic_hybrid_pass(
        self,
        sub_latent_slice: torch.Tensor,
        refinement_mode: str = "adaptive",
        intensity_scale: float = 1.0,
        step_ratio: float = 0.0
    ) -> torch.Tensor:
        """
        تطبيق معالجة هجينة موزونة مع مراعاة خصائص الـ Latent Space.
        """
        logger.debug(
            f"⚡ [Hybrid Pass Start] Shape: {sub_latent_slice.shape} | Mode: {refinement_mode} | "
            f"Intensity: {intensity_scale:.2f} | Step Ratio: {step_ratio:.2f}"
        )

        if sub_latent_slice.numel() == 0:
            logger.warning("⚠️ [Hybrid Pass Skipped] الـ Slice فارغ (numel == 0).")
            return sub_latent_slice

        # 1. نمط إبراز التفاصيل الحادة (High-Pass Detail Injection)
        if refinement_mode == "sharpen_edges":
            low_freq = F.avg_pool2d(sub_latent_slice, kernel_size=3, stride=1, padding=1)
            high_freq = sub_latent_slice - low_freq
            boost = 0.1 * intensity_scale * max(0.0, 1.0 - step_ratio)
            processed = sub_latent_slice + (high_freq * boost)
            logger.info(f"✨ [Sharpen Pass Applied] Boost factor: {boost:.4f}")
            return processed

        # 2. نمط التنعيم الهيكلي الآمن (Structure Fusion)
        elif refinement_mode == "smooth_structure":
            smoothed = F.avg_pool2d(sub_latent_slice, kernel_size=3, stride=1, padding=1)
            alpha = 0.15 * intensity_scale
            processed = (1.0 - alpha) * sub_latent_slice + alpha * smoothed
            logger.info(f"🌊 [Smooth Pass Applied] Alpha factor: {alpha:.4f}")
            return processed

        # 3. النمط المتردد التكيفي (Adaptive Dampening)
        elif refinement_mode == "adaptive":
            attenuation = 1.0 - (0.02 * intensity_scale * step_ratio)
            processed = sub_latent_slice * attenuation
            logger.info(f"📉 [Adaptive Pass Applied] Attenuation factor: {attenuation:.4f}")
            return processed

        logger.warning(f"⚠️ [Unknown Refinement Mode] النمط '{refinement_mode}' غير معروف. إرجاع الـ Slice كما هو.")
        return sub_latent_slice

    def apply_guarded_denoise_step(
        self,
        guardrail_payload: Dict[str, Any],
        noise_pred: torch.Tensor,
        sub_chambers_config: Optional[List[Dict[str, Any]]] = None,
        step_ratio: float = 0.0,
        denoise_strength: float = 0.85,
        **kwargs
    ) -> torch.Tensor:
        """
        تطبيق المعالجة الهجينة المتوازية مع التنعيم المكاني والدمج مع الـ Guardrail Payload.
        """
        logger.info(
            f"🛡️ [Guarded Denoise Step] Start | Noise Pred Shape: {noise_pred.shape} | "
            f"Step Ratio: {step_ratio:.2f} | Denoise Strength: {denoise_strength:.2f}"
        )

        if not sub_chambers_config and not guardrail_payload:
            logger.info("ℹ️ [Guarded Denoise Step] لا توجد إعدادات غرف فرعية أو حمولة Guardrail. تجاوز الخطوة.")
            return noise_pred

        _, _, h, w = noise_pred.shape
        base_noise_pred = noise_pred.clone()
        accumulated_delta = torch.zeros_like(noise_pred)

        # دمج قناع التوجيه من الـ Guardrail إن وجد
        guardrail_mask = guardrail_payload.get("bounded_latent_mask", None) if guardrail_payload else None
        if guardrail_mask is not None:
            logger.info(f"🔒 [Guardrail Mask Detected] Shape: {guardrail_mask.shape}")

        if sub_chambers_config:
            logger.info(f"🔄 [Processing Sub-Chambers] إجمالي الغرف الفرعية: {len(sub_chambers_config)}")
            for idx, config in enumerate(sub_chambers_config):
                mode = config.get("refinement_mode", "adaptive")
                intensity = config.get("intensity", 1.0) * denoise_strength
                normalized_bounds = config.get("bounds", (0.0, 0.0, 1.0, 1.0))
                
                logger.info(f"🧩 [Sub-Chamber #{idx+1}] Mode: {mode} | Intensity: {intensity:.2f} | Bounds: {normalized_bounds}")

                x1, y1, x2, y2 = self.transform_bounds_to_latent_coords(normalized_bounds, h, w)
                sub_slice = base_noise_pred[..., y1:y2, x1:x2]

                if sub_slice.numel() > 0:
                    processed_slice = self.process_dynamic_hybrid_pass(
                        sub_latent_slice=sub_slice,
                        refinement_mode=mode,
                        intensity_scale=intensity,
                        step_ratio=step_ratio
                    )
                    
                    slice_delta = processed_slice - sub_slice
                    
                    sub_h, sub_w = y2 - y1, x2 - x1
                    feather_mask = self._create_feathered_mask(
                        sub_h, sub_w, 
                        feather_radius=min(3, sub_h // 2, sub_w // 2), 
                        device=noise_pred.device, 
                        dtype=noise_pred.dtype
                    )
                    
                    if guardrail_mask is not None:
                        g_sub = guardrail_mask[..., y1:y2, x1:x2]
                        if g_sub.shape[-2:] == (sub_h, sub_w):
                            feather_mask = feather_mask * (1.0 + g_sub * 0.5)

                    accumulated_delta[..., y1:y2, x1:x2] += slice_delta * feather_mask

        # كبح الفرق لتفادي أي Overflow
        pre_clamp_max = accumulated_delta.abs().max().item()
        accumulated_delta = torch.clamp(accumulated_delta, min=-0.1, max=0.1)
        post_clamp_max = accumulated_delta.abs().max().item()

        logger.info(
            f"🎛️ [Accumulated Delta] Pre-clamp Max Abs: {pre_clamp_max:.6f} | Post-clamp Max Abs: {post_clamp_max:.6f}"
        )

        return base_noise_pred + accumulated_delta

    def resize_latent_tensor(
        self, 
        latents: torch.Tensor, 
        scale_factor: float = 2.0, 
        mode: str = "bicubic"
    ) -> torch.Tensor:
        """رفع/خفض أبعاد الـ Latent Tensors مع موازنة الانحراف المعياري للإشارة."""
        _, _, h, w = latents.shape
        new_h, new_w = int(h * scale_factor), int(w * scale_factor)

        logger.info(
            f"📐 [Resize Latent] Input Shape: {latents.shape} -> New Target: ({new_h}, {new_w}) | "
            f"Mode: {mode} | Scale Factor: {scale_factor}"
        )

        upscaled = F.interpolate(latents, size=(new_h, new_w), mode=mode, align_corners=False)
        
        std_orig = latents.std().item()
        std_up = upscaled.std().item()

        if std_up > 1e-5:
            correction_factor = std_orig / std_up
            upscaled = upscaled * correction_factor
            logger.info(
                f"⚖️ [Std Normalization] Orig Std: {std_orig:.4f} | Upscaled Std Pre: {std_up:.4f} | "
                f"Correction Factor: {correction_factor:.4f} | Post Std: {upscaled.std().item():.4f}"
            )
        else:
            logger.warning("⚠️ [Std Normalization Skipped] الانحراف المعياري للناتج قريب جداً من الصفر.")

        return upscaled


if __name__ == "__main__":
    logger.info("=== بدء الاختبار الذاتي لغرفة المعالجة الديناميكية (DenoisingChamberEngine) ===")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"🖥️ جهاز التشغيل المستهدف: {device}")

    chamber_engine = DenoisingChamberEngine(target_resolution=(512, 512))

    simulated_noise_pred = torch.randn((1, 4, 64, 64), device=device, dtype=torch.float32)
    logger.info(f"📊 حجم الـ Latent المحاكى: {simulated_noise_pred.shape}")

    mock_guardrail_mask = torch.ones((1, 1, 64, 64), device=device, dtype=torch.float32) * 0.5
    mock_guardrail_payload = {
        "bounded_latent_mask": mock_guardrail_mask
    }

    sub_chambers = [
        {
            "refinement_mode": "sharpen_edges",
            "intensity": 1.2,
            "bounds": (0.1, 0.1, 0.4, 0.4)
        },
        {
            "refinement_mode": "smooth_structure",
            "intensity": 0.8,
            "bounds": (0.5, 0.5, 0.4, 0.4)
        },
        {
            "refinement_mode": "adaptive",
            "intensity": 1.0,
            "bounds": (0.0, 0.0, 1.0, 1.0)
        }
    ]

    logger.info("🚀 جاري معالجة خطوة الـ Denoising الهجينة...")
    output_noise_pred = chamber_engine.apply_guarded_denoise_step(
        guardrail_payload=mock_guardrail_payload,
        noise_pred=simulated_noise_pred,
        sub_chambers_config=sub_chambers,
        step_ratio=0.25,
        denoise_strength=0.85
    )

    logger.info(f"✅ تم التنفيذ بنجاح! حجم الـ Latent الناتج: {output_noise_pred.shape}")
    logger.info(f"📈 أقصى تغير في الإشارة (Max Delta): {(output_noise_pred - simulated_noise_pred).abs().max().item():.6f}")

    logger.info("📐 جاري اختبار إعادة تحجيم الـ Latent Tensor مع موازنة الانحراف المعياري...")
    upscaled_latent = chamber_engine.resize_latent_tensor(simulated_noise_pred, scale_factor=2.0)
    logger.info(f"✨ الحجم بعد التكبير (2x): {upscaled_latent.shape} | Standard Deviation: {upscaled_latent.std().item():.4f}")

    logger.info("=== اكتملت جميع اختبارات DenoisingChamberEngine بنجاح تام ===")