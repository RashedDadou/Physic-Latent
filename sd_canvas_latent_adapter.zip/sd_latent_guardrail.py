# sd_latent_guardrail.py
"""
غرفة التحكم الهجينة الديناميكية (Dynamic Hybrid Latent Guardrail).
المسؤولية:
1. التنسيق بداخل غرفة التحكم باستخدام الاستدعاءات المحصورة والمنسق المطور.
2. تطبيق التسلسل الفيزيائي بتكامل مع الحقن المتردد والمراقبة والفلترة.
"""

from __future__ import annotations

import logging
from typing import Union, Dict, Tuple, Optional, Any
import numpy as np
import torch

# 🎯 الاستدعاءات المحصورة (تطبيقاً للهيكلية)
from sd_latent_grid import GroundGridGuardrail
from sd_latent_lighting import LatentLightingEngine
from sd_latent_camera import CameraManager, CameraGridCache
from sd_controlnet_orchestrator import SDControlNetOrchestrator

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("LATENT_GUARDRAIL")


class LatentChamberGuardrail:
    """غرفة التحكم الديناميكية بالمكبح الهجين والمنسق المتردد لـ ControlNet."""

    def __init__(
        self, 
        guidance_scale: float = 7.5, 
        strictness_factor: float = 0.85, 
        grid_mode: str = "1m"
    ):
        self.guidance_scale = guidance_scale
        self.strictness_factor = strictness_factor
        
        # 🟢 تهيئة المحركات والمنسق المطور
        self.grid_engine = GroundGridGuardrail(mode=grid_mode)
        self.lighting_engine = LatentLightingEngine()
        self.controlnet_orchestrator = SDControlNetOrchestrator()
        
        # 🟢 كائن الكاش الخاص بالكاميرا والشبكة
        self.camera_cache = CameraGridCache()
        
        logger.info(f"🛡️ [Guardrail Integrated Init] factor={strictness_factor}, guidance={guidance_scale}, grid={grid_mode}")

    def reset_chamber(self) -> None:
        """تصفير سياق غرفة التحكم والمنسق مع بداية كل توليد."""
        self.controlnet_orchestrator.reset_pipeline()

    def process_and_inject_conditioning(
        self,
        latent_tensor: torch.Tensor,
        depth_map: Optional[Union[np.ndarray, torch.Tensor]] = None,
        canvas_mask: Optional[Union[np.ndarray, torch.Tensor]] = None,
        grid_mask: Optional[Union[np.ndarray, torch.Tensor]] = None,
        control_input: Optional[Union[np.ndarray, torch.Tensor]] = None,
        current_step: int = 0,
        total_steps: int = 20,
        device: Optional[torch.device] = None,
        camera_data: Optional[Dict[str, Any]] = None,
        light_config: Optional[Dict[str, Any]] = None,
        controlnet_strength: float = 1.0
    ) -> Dict[str, Any]:
        """
        إدارة وحقن التوجيه بداخل غرفة التحكم بالاعتماد على المنسق المتردد والمراقب والفلتر.
        """
        target_device = device if device is not None else latent_tensor.device
        target_dtype = latent_tensor.dtype
        lh, lw = latent_tensor.shape[-2], latent_tensor.shape[-1]
        latent_shape = (lh, lw)
        step_ratio = current_step / max(1, total_steps)

        # =========================================================================
        # 1. إدارة واسترجاع الشبكة الأرضية
        # =========================================================================
        current_cam_sig = CameraManager.build_camera_signature(camera_data)
        
        if grid_mask is None:
            if self.camera_cache.is_valid(latent_shape, current_cam_sig, target_device):
                grid_tensor = self.camera_cache.get_mask(target_dtype)
            else:
                raw_grid = GroundGridGuardrail.generate_ground_grid_mask(
                    latent_shape=latent_shape,
                    grid_engine=self.grid_engine,
                    camera_data=camera_data
                )
                grid_tensor = torch.from_numpy(raw_grid).to(device=target_device, dtype=target_dtype).unsqueeze(0).unsqueeze(0)
                self.camera_cache.update(latent_shape, grid_tensor, current_cam_sig)
        else:
            grid_tensor = grid_mask if isinstance(grid_mask, torch.Tensor) else torch.from_numpy(grid_mask).to(device=target_device, dtype=target_dtype)

        # =========================================================================
        # 2. تجهيز وتطبيق العمق والـ Canvas
        # =========================================================================
        if depth_map is not None:
            depth_tensor = depth_map if isinstance(depth_map, torch.Tensor) else torch.from_numpy(depth_map).to(device=target_device, dtype=target_dtype)
            if depth_tensor.ndim == 2:
                depth_tensor = depth_tensor.unsqueeze(0).unsqueeze(0)
        else:
            depth_tensor = torch.zeros((1, 1, lh, lw), device=target_device, dtype=target_dtype)

        temporal_weight = max(0.0, 1.0 - (step_ratio / 0.6)) ** 2
        depth_conditioning_mask = depth_tensor * temporal_weight * self.strictness_factor

        # أ) تطبيق Depth
        latent_stage_1 = latent_tensor * (1.0 + depth_conditioning_mask * 0.12)

        # ب) تطبيق Canvas
        if canvas_mask is not None:
            canvas_tensor = canvas_mask if isinstance(canvas_mask, torch.Tensor) else torch.from_numpy(canvas_mask).to(device=target_device, dtype=target_dtype)
            canvas_gain = canvas_tensor * 0.08 * (1.0 - step_ratio)
            latent_stage_1 = latent_stage_1 * (1.0 + canvas_gain)

        # =========================================================================
        # 3. معالجة ControlNet المتردد عبر Orchestrator (Monitor + Pulse + Filter)
        # =========================================================================
        controlnet_payload = self.controlnet_orchestrator.process_and_step_inject(
            latent_tensor=latent_stage_1,
            control_input=control_input,
            current_step=current_step,
            total_steps=total_steps,
            device=target_device,
            control_strength=controlnet_strength
        )
        latent_stage_2 = controlnet_payload["guarded_latent"]

        # =========================================================================
        # 4. حقن الإضاءة والظلال عبر LatentLightingEngine
        # =========================================================================
        lighting_payload = self.lighting_engine.inject_lighting_conditioning(
            latent_tensor=latent_stage_2,
            depth_grid=depth_tensor,
            step_ratio=step_ratio,
            light_config=light_config,
            device=target_device,
            dtype=target_dtype
        )

        guarded_latent = torch.clamp(lighting_payload["guarded_latent"], min=-4.0, max=4.0)

        return {
            "guarded_latent": guarded_latent,
            "bounded_latent_mask": depth_conditioning_mask,
            "depth_tensor": depth_tensor,
            "grid_tensor": grid_tensor,
            "control_tensor": controlnet_payload["control_tensor"],
            "injected_this_step": controlnet_payload["injected_this_step"],
            "lighting_mask": lighting_payload["lighting_mask_tensor"],
            "shadow_map": lighting_payload["shadow_map_tensor"]
        }