# sd_latent_camera.py
"""
وحدة إدارة بيانات الكاميرا وتحويل المنظور الـ Latent (Latent Camera Manager, Cache & Warper) - النسخة الصارمة (Strict & Explicit).

المسؤولية:
1. التحقق الصارم والمباشر من متجهات الكاميرا والمفاتيح الأساسية بدون .get() أو أغطية احترازية.
2. عزل ذاكرة GPU عن NumPy أثناء حساب تحويلات الكاميرا (Warping & Caching).
3. إجراء تحويل المنظور الفيزيائي (3D Perspective Warping) لمصفوفات الـ Latents صراحة بين إطارين.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Tuple, Union
import numpy as np
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("LATENT_CAMERA")


class CameraManager:
    """وحدة معالجة متجهات الكاميرا وإنشاء البصمات الموحدة بصرامة."""

    REQUIRED_KEYS = ["pos", "forward", "up", "right", "focal_pixel"]

    @classmethod
    def validate_camera_dict(cls, camera_data: Dict[str, Any]) -> None:
        """فحص صريح لمفاتيح الكاميرا لضمان التوافق وتطبيق Fail-Fast."""
        if not isinstance(camera_data, dict) or not camera_data:
            raise TypeError("camera_data يجب أن يكون قاموساً صريحاً وغير فارغ.")
        
        missing = [k for k in cls.REQUIRED_KEYS if k not in camera_data]
        if missing:
            raise KeyError(f"❌ [CameraManager Fail-Fast] camera_data تفتقر للمفاتيح المطلوبة: {missing}")

    @staticmethod
    def clean_vector(val: Any, decimals: int) -> Tuple[float, ...]:
        """تجهيز وتنظيف متجهات الكاميرا بعد تحويل التنسورات من GPU إلى CPU بآمان."""
        if val is None:
            raise ValueError("Vector value cannot be None.")
        if isinstance(val, torch.Tensor):
            val = val.detach().cpu().numpy()
        val = np.asarray(val, dtype=np.float32).flatten()
        return tuple(np.round(val, decimals).tolist())

    @classmethod
    def build_camera_signature(cls, camera_data: Dict[str, Any], decimals: int) -> Tuple:
        """إنشاء بصمة فريدة ونقية لمتجهات الكاميرا لمقارنتها بالـ Cache بدون .get() احترازي."""
        cls.validate_camera_dict(camera_data)

        pos = cls.clean_vector(camera_data["pos"], decimals)
        fwd = cls.clean_vector(camera_data["forward"], decimals)
        up = cls.clean_vector(camera_data["up"], decimals)
        right = cls.clean_vector(camera_data["right"], decimals)
        focal = float(np.round(float(camera_data["focal_pixel"]), 2))

        sig = (pos, fwd, up, right, focal)
        logger.debug(f"Built Camera Signature: {sig}")
        return sig


class CameraGridCache:
    """إدارة الذاكرة المؤقتة لقناع الشبكة الأرضية وحالة الكاميرا."""

    def __init__(self):
        self._cached_shape: Union[Tuple[int, int], None] = None
        self._cached_mask: Union[torch.Tensor, None] = None
        self._cache_key: Union[int, None] = None
        self._frozen_camera_ref: Union[int, None] = None
        logger.info("Initialized CameraGridCache instance.")

    def _generate_cache_key(
        self, camera_data: Dict[str, Any], target_shape: Tuple[int, int]
    ) -> int:
        CameraManager.validate_camera_dict(camera_data)

        pos = CameraManager.clean_vector(camera_data["pos"], 4)
        fwd = CameraManager.clean_vector(camera_data["forward"], 4)
        up = CameraManager.clean_vector(camera_data["up"], 4)
        right = CameraManager.clean_vector(camera_data["right"], 4)
        focal = round(float(camera_data["focal_pixel"]), 2)

        cache_hash = hash((pos, fwd, up, right, focal, target_shape))
        return cache_hash

    def get_mask_or_none(
        self,
        camera_data: Dict[str, Any],
        target_shape: Tuple[int, int],
        device: torch.device,
        dtype: torch.dtype,
    ) -> Union[torch.Tensor, None]:
        """جلب القناع من الكاش بصرامة وحزم."""
        if self._cached_mask is None or self._cached_shape != target_shape:
            logger.debug("Cache miss: Mask is None or target shape mismatched.")
            return None

        # 1. Reference Freeze
        if id(camera_data) == self._frozen_camera_ref:
            logger.debug("⚡ [CameraGridCache] Cache HIT via Fast-Path Reference Freeze.")
            return self._cached_mask.to(device=device, dtype=dtype)

        # 2. Precision Hash Check
        current_key = self._generate_cache_key(camera_data, target_shape)
        if self._cache_key == current_key and self._cached_mask.device == device:
            self._frozen_camera_ref = id(camera_data)
            logger.debug("🔒 [CameraGridCache] Cache HIT via Precision Hash match.")
            return self._cached_mask.to(dtype=dtype)

        logger.debug("Cache miss: Camera key precision mismatch.")
        return None

    def update(
        self,
        camera_data: Dict[str, Any],
        target_shape: Tuple[int, int],
        mask_tensor: torch.Tensor,
    ) -> None:
        self._cached_shape = target_shape
        self._cached_mask = mask_tensor
        self._cache_key = self._generate_cache_key(camera_data, target_shape)
        self._frozen_camera_ref = id(camera_data)
        logger.info(
            f"🔒 [CameraGridCache] Updated and frozen cache | shape={target_shape}, device={mask_tensor.device}"
        )

    def clear(self) -> None:
        self._cached_shape = None
        self._cached_mask = None
        self._cache_key = None
        self._frozen_camera_ref = None
        logger.info("Cleared CameraGridCache.")


class LatentCameraWarper:
    """محرك تحويل المنظور الفيزيائي لمصفوفات الـ Latents."""

    @staticmethod
    def _to_numpy_vector(val: Any) -> np.ndarray:
        """تحويل صريح لمتجهات الكاميرا إلى NumPy بغض النظر عن الـ device الأصلي."""
        if isinstance(val, torch.Tensor):
            return val.detach().cpu().numpy().astype(np.float32)
        return np.asarray(val, dtype=np.float32)

    @classmethod
    def warp_latent_space(
        cls,
        latents: torch.Tensor,
        old_cam_data: Dict[str, Any],
        new_cam_data: Dict[str, Any],
        depth_map: torch.Tensor,
        device: torch.device,
        dtype: torch.dtype
    ) -> torch.Tensor:
        """تحريك قيم الـ Latent Tensor حركياً مع الفحص الصارم للـ camera_data."""
        CameraManager.validate_camera_dict(old_cam_data)
        CameraManager.validate_camera_dict(new_cam_data)

        latents = latents.to(device=device, dtype=dtype)
        depth_map = depth_map.to(device=device, dtype=dtype)
        b, c, h, w = latents.shape

        logger.info(f"Warping latent space tensor | input_shape={tuple(latents.shape)}, device={device}, dtype={dtype}")

        focal = float(new_cam_data["focal_pixel"])

        grid_y, grid_x = torch.meshgrid(
            torch.linspace(-1.0, 1.0, steps=h, device=device, dtype=dtype),
            torch.linspace(-1.0, 1.0, steps=w, device=device, dtype=dtype),
            indexing="ij"
        )

        # 1. الاستخراج الآمن وتحويل المتجهات لـ NumPy بعد فصل الـ CUDA Stream
        old_pos = cls._to_numpy_vector(old_cam_data["pos"])
        new_pos = cls._to_numpy_vector(new_cam_data["pos"])
        pos_delta = new_pos - old_pos

        R_old = np.stack([
            cls._to_numpy_vector(old_cam_data["right"]),
            cls._to_numpy_vector(old_cam_data["up"]),
            cls._to_numpy_vector(old_cam_data["forward"])
        ], axis=0)

        R_new = np.stack([
            cls._to_numpy_vector(new_cam_data["right"]),
            cls._to_numpy_vector(new_cam_data["up"]),
            cls._to_numpy_vector(new_cam_data["forward"])
        ], axis=0)

        R_rel = torch.from_numpy(R_new @ R_old.T).to(device=device, dtype=dtype)

        # 2. حساب Backward Mapping Flow بواسطة depth_map صريحة
        depth_squeezed = depth_map.squeeze()
        if depth_squeezed.ndim != 2 or depth_squeezed.shape != (h, w):
            raise ValueError(f"depth_map shape {depth_map.shape} is incompatible with target resolution {(h, w)}.")

        dx = (pos_delta[0] * R_rel[0, 0] + pos_delta[2] * R_rel[0, 2]) / (depth_squeezed + 1e-5)
        dy = (pos_delta[1] * R_rel[1, 1] + pos_delta[2] * R_rel[1, 2]) / (depth_squeezed + 1e-5)

        sampling_grid_x = grid_x - (dx * (2.0 / w))
        sampling_grid_y = grid_y - (dy * (2.0 / h))

        sampling_grid = torch.stack((sampling_grid_x, sampling_grid_y), dim=-1).unsqueeze(0)
        if b > 1:
            sampling_grid = sampling_grid.repeat(b, 1, 1, 1)

        # 3. إنجاز Grid Sampling
        warped_latents = F.grid_sample(
            latents,
            sampling_grid,
            mode='bilinear',
            padding_mode='border',
            align_corners=True
        )

        logger.info(f"📐 [Latent Camera Warper] Successfully warped latents to shape: {tuple(warped_latents.shape)}")
        return warped_latents


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running LatentCamera Strict Integration Test")
    print("=" * 60 + "\n")

    test_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    test_dtype = torch.float32

    cam_start = {
        "pos": torch.tensor([0.0, 1.5, -5.0], device=test_device),
        "forward": torch.tensor([0.0, 0.0, 1.0], device=test_device),
        "up": torch.tensor([0.0, 1.0, 0.0], device=test_device),
        "right": torch.tensor([1.0, 0.0, 0.0], device=test_device),
        "focal_pixel": 600.0
    }

    cam_shifted = {
        "pos": torch.tensor([0.5, 1.5, -4.8], device=test_device),
        "forward": torch.tensor([0.0, 0.0, 1.0], device=test_device),
        "up": torch.tensor([0.0, 1.0, 0.0], device=test_device),
        "right": torch.tensor([1.0, 0.0, 0.0], device=test_device),
        "focal_pixel": 600.0
    }

    # اختبار إنشاء البصمة وتحول التنسورات القادمة من CUDA بدون أخطاء
    sig = CameraManager.build_camera_signature(cam_start, decimals=4)
    print(f"✅ Camera Signature Generated Safely: {sig[0]}")

    cache = CameraGridCache()
    dummy_mask = torch.ones((1, 1, 64, 64), device=test_device, dtype=test_dtype)
    cache.update(cam_start, (64, 64), dummy_mask)

    mask_retrieved = cache.get_mask_or_none(cam_start, (64, 64), device=test_device, dtype=test_dtype)
    print(f"✅ Cache Status: {'HIT' if mask_retrieved is not None else 'MISS'}")

    dummy_latent = torch.randn((1, 4, 64, 64), device=test_device, dtype=test_dtype)
    dummy_depth = torch.ones((1, 1, 64, 64), device=test_device, dtype=test_dtype) * 2.5

    warped = LatentCameraWarper.warp_latent_space(
        latents=dummy_latent,
        old_cam_data=cam_start,
        new_cam_data=cam_shifted,
        depth_map=dummy_depth,
        device=test_device,
        dtype=test_dtype
    )

    print(f"✅ Latent Warped Shape: {warped.shape} | Device: {warped.device}")