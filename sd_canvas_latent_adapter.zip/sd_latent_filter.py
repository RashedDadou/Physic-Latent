# sd_latent_filter.py
"""
محرك التنقية والفلترة اللحظية لـ Latent Space (Latent Filter & Smoothing Engine).
المسؤولية:
1. تطبيق التنعيم المكتبي/الفيزيائي (Gaussian Blur / Soft Clamping) على التعديلات المضافة.
2. تطبيع المدى الإحصائي لتجنب الحرق والحواف الحادة.
3. عزل تام عن المنسق والمراقب.
"""

from __future__ import annotations

import logging
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("LATENT_FILTER")


class LatentFilterEngine:
    """محرك التنقية والفلترة للحفاظ على سلامة التوزيع الإحصائي لـ Latent."""

    def __init__(self, blur_kernel_size: int, clamp_range: float):
        if blur_kernel_size % 2 == 0 or blur_kernel_size <= 0:
            raise ValueError(f"blur_kernel_size must be a positive odd integer, got {blur_kernel_size}")
        if clamp_range <= 0:
            raise ValueError(f"clamp_range must be positive, got {clamp_range}")

        self.blur_kernel_size = blur_kernel_size
        self.clamp_range = clamp_range
        logger.info(f"🧹 [Filter Engine Init] kernel={blur_kernel_size}, clamp_range={clamp_range}")

    def apply_injection_filter(
        self,
        latent_tensor: torch.Tensor,
        smoothing_strength: float,
        device: torch.device,
        dtype: torch.dtype
    ) -> torch.Tensor:
        """
        تطبيق تنقية وتنعيم خفيف عقب كل حقن للحفاظ على سلاسة الحواف وتوازن المدى بصراحة كاملة.
        """
        if not isinstance(latent_tensor, torch.Tensor):
            raise TypeError("latent_tensor must be a valid torch.Tensor.")
        if not (0.0 <= smoothing_strength <= 1.0):
            raise ValueError(f"smoothing_strength must be between 0.0 and 1.0, got {smoothing_strength}")

        latent_tensor = latent_tensor.to(device=device, dtype=dtype)

        with torch.no_grad():
            filtered_latent = latent_tensor.clone()

            # 1. تنعيم حواف التغيرات (Low-pass Softening) عبر AvgPool لتقليل النويز الحاد
            if smoothing_strength > 0.0:
                pad_size = self.blur_kernel_size // 2
                padded = F.pad(filtered_latent, (pad_size, pad_size, pad_size, pad_size), mode='reflect')
                smoothed = F.avg_pool2d(padded, kernel_size=self.blur_kernel_size, stride=1)
                filtered_latent = torch.lerp(filtered_latent, smoothed, weight=smoothing_strength)
                logger.debug(f"Applied Low-pass smoothing with strength={smoothing_strength:.4f}")

            # 2. تقليم النطاق الإحصائي (Soft Clamping) للحد من القيم الشاذة
            filtered_latent = torch.clamp(
                filtered_latent,
                min=-self.clamp_range,
                max=self.clamp_range
            )
            logger.debug(f"Clamped latent values within range [-{self.clamp_range}, {self.clamp_range}]")

        return filtered_latent


# ==============================================================================
#  تست وحقن تجريبي (Main Execution Entry Point)
# ==============================================================================
if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("🚀 Running LatentFilterEngine Integration Test")
    print("=" * 60 + "\n")

    test_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    test_dtype = torch.float32

    filter_engine = LatentFilterEngine(blur_kernel_size=3, clamp_range=4.0)

    # إنشاء Latent ذو قيم عالية شاذة لاختبار الفلترة
    noisy_latent = torch.randn((1, 4, 64, 64), device=test_device, dtype=test_dtype) * 3.0
    noisy_latent[0, 0, 10, 10] = 10.0  # Outlier value

    print(f"Original Latent - Min: {noisy_latent.min().item():.4f}, Max: {noisy_latent.max().item():.4f}")

    filtered = filter_engine.apply_injection_filter(
        latent_tensor=noisy_latent,
        smoothing_strength=0.1,
        device=test_device,
        dtype=test_dtype
    )

    print(f"Filtered Latent - Min: {filtered.min().item():.4f}, Max: {filtered.max().item():.4f}")
    print(f"Device: {filtered.device} | Dtype: {filtered.dtype}")
    print("\n✅ Self-Test Completed Successfully!")