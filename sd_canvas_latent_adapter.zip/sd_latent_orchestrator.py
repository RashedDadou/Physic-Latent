# sd_latent_orchestrator.py
"""
المنسق المركزي الموحد (SD Latent Simulation Pipeline Orchestrator).
الوظيفة: ربط محرك المقنعات الفيزيائية ومحرك الخامات وم المنسق الفرعي لـ ControlNet 
مع نموذج Stable Diffusion v1.5 لتوليد صور معالجة فيزيائياً ومكانياً.
"""

from __future__ import annotations

import os
import logging
from typing import Dict, List, Tuple, Any, Optional, Union
import numpy as np
import torch
from diffusers import StableDiffusionPipeline, DDIMScheduler

# استدعاء المحركات المستقلة والوحدات المنسقة
from canvas_steps_adapter import CanvasLatentAdapter, PhysicalEntity3D
from sd_conditioning_synthesizer import ConditioningSynthesizer
from sd_controlnet_orchestrator import SDControlNetOrchestrator

# تفعيل وضع Offline لتفادي طلبات HTTP HEAD أثناء التشغيل
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"

# ضبط إعدادات السجل القياسية
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | [%(name)s] %(message)s")
logger = logging.getLogger("SD_LATENT_ORCHESTRATOR")

def _ensure_physical_entity(entity):
    """تحويل الـ dict إلى PhysicalEntity3D بأسلوب آمن وتلقائي."""
    if isinstance(entity, dict):
        return PhysicalEntity3D(**entity)
    return entity
    
class SDLatentOrchestrator:
    """المنسق الشامل لإدارة محاكاة الـ Latents وتوليد الصور مع Stable Diffusion."""

    def __init__(
        self,
        model_id_or_path: str = "runwayml/stable-diffusion-v1-5",
        device_input: Union[str, torch.device] = "cuda",
        grid_resolution: Tuple[int, int] = (256, 256),
        latent_shape: Tuple[int, int] = (64, 64),
        torch_dtype: torch.dtype = torch.float16
    ):
        if isinstance(device_input, torch.device):
            self.device = device_input
        else:
            self.device = torch.device(device_input if torch.cuda.is_available() else "cpu")

        self.torch_dtype = torch_dtype if self.device.type == "cuda" else torch.float32
        self.grid_resolution = grid_resolution
        self.latent_shape = latent_shape

        logger.info(f"🚀 [Orchestrator Init] بدء تحميل المنسق الموحد على الجهاز: {self.device}")

        # 1. تهيئة المحركات الثلاثة المستوردة
        self.canvas_adapter = CanvasLatentAdapter()
        self.conditioning_synthesizer = ConditioningSynthesizer()
        self.controlnet_orchestrator = SDControlNetOrchestrator(
            device_input=self.device,
            grid_resolution=self.latent_shape,
            target_resolution=(512, 512)
        )

        # 2. تحميل خط أنابيب Stable Diffusion
        logger.info(f"📦 [Model Load] تحميل نموذج Stable Diffusion من: {model_id_or_path}")
        self.pipe = StableDiffusionPipeline.from_pretrained(
            model_id_or_path,
            local_files_only=True,
            dtype=self.torch_dtype,      # ✅ استبدال torch_dtype بـ dtype
            safety_checker=None,         # ✅ تعطيل وحدة فحص الأمان لتفادي البحث عن ملفاتها
            feature_extractor=None       # ✅ تعطيل استخراج الخصائص الخاص بالأمان
        ).to(self.device)

        # تعيين مبرمج الخطوات DDIM لسرعة واستقرار التوليد
        self.pipe.scheduler = DDIMScheduler.from_config(self.pipe.scheduler.config)
        logger.info("✅ [Model Ready] تم تحميل النموذج وتحديث DDIMScheduler بنجاح.")

    def run_simulation_pipeline(
        self,
        prompt: str,
        negative_prompt: str = "",
        entities: Optional[List[PhysicalEntity3D]] = None,
        material_inputs: Optional[Union[List[str], Dict[str, str]]] = None,
        camera_pos: Tuple[float, float, float] = (0.0, 0.0, 0.0),
        camera_forward: Tuple[float, float, float] = (0.0, 0.0, 1.0),
        camera_up: Tuple[float, float, float] = (0.0, 1.0, 0.0),
        camera_right: Tuple[float, float, float] = (1.0, 0.0, 0.0),
        focal_length: float = 35.0,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5,
        control_strength: float = 0.8,
        seed: int = 42
    ) -> Dict[str, Any]:
        """
        التدفق الكامل لعملية المحاكاة والحقن والتوليد:
        1. إسقاط الكائنات ثلاثية الأبعاد إلى شبكة Canvas وعمق (Rasterization).
        2. تحويل الشبكة لـ Latent Tensor وتطبيق حقن المواد مكانياً.
        3. إجراء معالجة Denoising متسلسلة عبر ControlNet Orchestrator.
        4. إنتاج الصورة النهائية عبر Stable Diffusion.
        """
        logger.info("🎬 [Pipeline Start] بدء جولة توليد جديدة ومحاكاة فيزيائية...")
        torch.manual_seed(seed)
        np.random.seed(seed)

        # --- الخطوة 1: التنقيط وإسقاط الكيانات (Rasterization) ---
        if entities is not None:
            entities = [_ensure_physical_entity(e) for e in entities]

        canvas_grid, depth_grid = self.canvas_adapter.render_scene_with_camera(
            entities=entities,
            grid_shape=self.grid_resolution,
            camera_pos=np.array(camera_pos, dtype=np.float32),
            camera_right=np.array(camera_right, dtype=np.float32),
            camera_up=np.array(camera_up, dtype=np.float32),
            camera_forward=np.array(camera_forward, dtype=np.float32),
            focal_length=focal_length
        )

        # --- الخطوة 2: التحويل لـ Latent وحقن المواد (Conditioning Synthesis) ---
        latent_mask_tensor = CanvasLatentAdapter.convert_grid_to_latent_tensor(
            canvas_grid=canvas_grid,
            target_latent_shape=self.latent_shape,
            device=self.device,
            dtype=self.torch_dtype
        )

        material_payload = self.conditioning_synthesizer.build_conditioning_payload(
            canvas_grid=canvas_grid,
            latent_mask_tensor=latent_mask_tensor,
            entities=entities,
            depth_grid=depth_grid,
            material_input=material_inputs
        )

        # --- الخطوة 3: تجهيز إشارة التحكم والـ Latents الابتدائية ---
        injected_grid = material_payload["injected_material_grid"]
        
        # إنشاء Latent ذو ضوضاء عشوائية (Initial Noise Latent)
        latents = torch.randn(
            (1, self.pipe.unet.config.in_channels, self.latent_shape[0], self.latent_shape[1]),
            device=self.device,
            dtype=self.torch_dtype
        )

        # --- الخطوة 4: حلقة التنسيق والتنعيم عبر SDControlNetOrchestrator ---
        self.controlnet_orchestrator.reset_orchestrator()

        for step in range(1, num_inference_steps + 1):
            latents, step_summary = self.controlnet_orchestrator.orchestrate_denoising_pass(
                current_latent=latents,
                current_step=step,
                total_steps=num_inference_steps,
                control_input=injected_grid,
                camera_pos=camera_pos,
                control_strength=control_strength
            )

        # --- الخطوة 5: التوليد النهائي للصورة من الـ Latent المعالج عبر VAE ---
        logger.info("🖼️ [Diffusion Pass] فك تشفير الـ Latents المحقونة باستخدام VAE Decoder...")
        
        with torch.no_grad():
            # 1. تطبيع الـ Latents بحسب معامل الحجم الخاص بـ SD v1.5 ( scaling_factor = 0.18215 )
            scaling_factor = getattr(self.pipe.vae.config, "scaling_factor", 0.18215)
            latents_scaled = latents / scaling_factor

            # 2. تحويل الـ Latent Space إلى RGB Image Tensors
            decoded_tensor = self.pipe.vae.decode(latents_scaled, return_dict=False)[0]

            # 3. معالجة وتطبيع المصفوفة الناتجة إلى نطاق [0, 1]
            image_tensor = (decoded_tensor / 2.0 + 0.5).clamp(0.0, 1.0)
            
            # 4. التحويل إلى NumPy ثم إلى PIL Image
            image_np = image_tensor.cpu().permute(0, 2, 3, 1).float().numpy()[0]
            generated_image = self.pipe.numpy_to_pil(image_np)[0]

        # 5. تحويل خريطة العمق (depth_grid) إلى صورة PIL إذا كانت Tensor أو NumPy
        depth_pil = None
        if depth_grid is not None:
            if isinstance(depth_grid, torch.Tensor):
                d_np = depth_grid.detach().cpu().squeeze().numpy()
            else:
                d_np = np.array(depth_grid)
            
            # تطبيع خريطة العمق لمدى [0, 255] للعرض
            d_min, d_max = d_np.min(), d_np.max()
            if d_max - d_min > 1e-5:
                d_norm = ((d_np - d_min) / (d_max - d_min) * 255.0).astype(np.uint8)
            else:
                d_norm = (d_np * 255.0).clip(0, 255).astype(np.uint8)
                
            from PIL import Image
            depth_pil = Image.fromarray(d_norm).convert("L")

        logger.info("✨ [Pipeline Complete] اكتملت عملية التوليد وفك التشفير بنجاح تام.")

        return {
            "rendered_image": generated_image,
            "depth_image": depth_pil,
            "latent_tensor": latents,
            "canvas_grid": canvas_grid,
            "injected_material_grid": injected_grid
        }
        
# ==============================================================================
# MAIN EXECUTION BLOCK (اختبار التجميع والتشغيل المباشر)
# ==============================================================================
if __name__ == "__main__":
    logger.info("=========================================================")
    logger.info("🚀 بدء الاختبار الذاتي للمنسق المركزي sd_latent_orchestrator")
    logger.info("=========================================================")

    # 1. إعداد الكيانات ثلاثية الأبعاد
    glass_cup = PhysicalEntity3D(
        name="Glass_Cup",
        center_xyz=(0.0, 0.0, 2.0),
        dimensions_lwh=(0.5, 0.5, 1.0),
        density_weight=0.9,
        shape_type="cylinder"
    )

    chrome_pillar = PhysicalEntity3D(
        name="Chrome_Pillar",
        center_xyz=(1.2, 0.0, 3.5),
        dimensions_lwh=(0.8, 0.8, 2.5),
        density_weight=1.0,
        shape_type="cylinder"
    )

    test_entities = [glass_cup, chrome_pillar]

    materials_map = {
        "Glass_Cup": "glass",
        "Chrome_Pillar": "metal_chrome"
    }

    # 2. تشغيل المنسق (تخطي التحميل الفعلي للنموذج إن لم تتوفر الأوزان المحلية أثناء الاختبار)
    try:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        orchestrator = SDLatentOrchestrator(
            model_id_or_path="runwayml/stable-diffusion-v1-5",
            device_input=device,
            grid_resolution=(256, 256),
            latent_shape=(64, 64)
        )

        results = orchestrator.run_simulation_pipeline(
            prompt="a crystal glass cup and a shiny chrome pillar on a modern table, highly detailed, 8k photo",
            negative_prompt="blurry, distorted, low quality",
            entities=test_entities,
            material_inputs=materials_map,
            num_inference_steps=10,
            control_strength=0.85
        )

        logger.info(f"📊 نتيجة الاختبار: تم توليد صورة بحجم {results['image'].size}")
        logger.info("✅ اكتمل اختبار المنسق المركزي بنجاح!")

    except Exception as e:
        logger.warning(f"ℹ️ تنبيه أثناء تشغيل الاختبار (قد يعود لعدم وجود مسار النماذج المحلي): {e}")