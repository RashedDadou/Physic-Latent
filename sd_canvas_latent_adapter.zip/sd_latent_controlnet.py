# sd_latent_controlnet.py
"""
محرك معالجة وتأطير إشارات ControlNet لـ Latent Space (Latent ControlNet Engine).
المسؤولية:
1. تحويل وإعادة تشكيل مصفوفات ControlNet وإشارات التوجيه الهيكلية.
2. معالجة وتطبيع القوة التوجيهية وتنعيم الحواف للحفاظ على المدى الإحصائي لـ Latent.
3. معزول تماماً ولا يعتمد على طبقات المنسق المباشرة.
"""

from __future__ import annotations

import logging
from typing import Union, Tuple, Optional
import numpy as np
import torch
import torch.nn.functional as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("LATENT_CONTROLNET")


class LatentControlNetEngine:
    """محرك معالجة وحساب أقنعة ControlNet على مستوى الـ Latent."""

    def __init__(self, default_strength: float = 1.0):
        self.default_strength = default_strength
        logger.info(f"🕹️ [ControlNet Engine Init] default_strength={default_strength:.2f}")

    def prepare_control_tensor(
        self,
        control_input: Optional[Union[np.ndarray, torch.Tensor]],
        target_shape: Tuple[int, int],
        device: torch.device,
        dtype: torch.dtype
    ) -> torch.Tensor:
        """تحويل وتنسيق المدخلات الهيكلية لـ ControlNet إلى Tensor رباعي الأبعاد."""
        logger.info(
            f"🔄 [Prepare Control Tensor] Target Shape: {target_shape} | "
            f"Input Type: {type(control_input).__name__} | Device: {device} | Dtype: {dtype}"
        )

        if control_input is None:
            logger.warning("⚠️ [Prepare Control Tensor] الإدخال فارغ (None). إنشاء Tensor صفري بحجم التارجت.")
            return torch.zeros((1, 1, target_shape[0], target_shape[1]), device=device, dtype=dtype)

        if isinstance(control_input, np.ndarray):
            logger.debug(f"📐 [Input Array] Orig Shape: {control_input.shape} | Dtype: {control_input.dtype}")
            clean_data = np.nan_to_num(control_input, nan=0.0, posinf=0.0, neginf=0.0)
            tensor = torch.from_numpy(clean_data).to(device=device, dtype=dtype)
        elif isinstance(control_input, torch.Tensor):
            logger.debug(f"📐 [Input Tensor] Orig Shape: {control_input.shape} | Dtype: {control_input.dtype}")
            tensor = torch.nan_to_num(control_input, nan=0.0, posinf=0.0, neginf=0.0).to(device=device, dtype=dtype)
        else:
            logger.error(f"❌ [Type Error] نمط البيانات الممرر غير مدعوم: {type(control_input)}")
            raise TypeError(f"نمط البيانات الممرر غير مدعوم في ControlNet: {type(control_input)}")

        # رفع الأبعاد إلى 4D
        pre_dim_shape = tensor.shape
        while tensor.ndim < 4:
            tensor = tensor.unsqueeze(0)
        if tensor.shape != pre_dim_shape:
            logger.info(f"⬆️ [Dimension Expansion] Shape reshaped: {pre_dim_shape} -> {tensor.shape}")

        # إعادة التحجيم إن اختلف البعد المكانِي
        if tensor.shape[-2:] != target_shape:
            orig_spatial = tensor.shape[-2:]
            tensor = F.interpolate(
                tensor,
                size=target_shape,
                mode="bilinear",
                align_corners=False
            )
            logger.info(f"📐 [Interpolation Applied] Spatial resized: {orig_spatial} -> {target_shape}")

        logger.info(
            f"✅ [Prepare Control Tensor Completed] Final Shape: {tensor.shape} | "
            f"Min: {tensor.min().item():.4f} | Max: {tensor.max().item():.4f}"
        )
        return tensor

    def compute_control_gain(
        self,
        control_tensor: torch.Tensor,
        step_ratio: float = 0.0,
        strength: Optional[float] = None
    ) -> torch.Tensor:
        """حساب الكسب التوجيهي (Control Gain) مع الحفاظ على القيمة الإحصائية واستقرار الـ Latent."""
        effective_strength = strength if strength is not None else self.default_strength
        logger.info(
            f"🎛️ [Compute Control Gain] Start | Tensor Shape: {control_tensor.shape} | "
            f"Step Ratio: {step_ratio:.3f} | Effective Strength: {effective_strength:.2f}"
        )

        # 1. التحقق من السعة الكلية للإشارة بدلاً من max المباشر
        tensor_abs_max = torch.max(torch.abs(control_tensor)).item()
        if tensor_abs_max < 1e-7:
            logger.warning("⚠️ [Compute Control Gain] الإدخال صفري أو قريب جداً من الصفر. إرجاع الـ Tensor كما هو.")
            return control_tensor

        # 2. منحنى تناقص زمني سلس (Smooth Cosine Decay) يمنع الهبوط المفاجئ ويحتفظ بـ Floor بقيمة 5%
        # يتدرج بسلاسة بدلاً من الانقطاع عند step_ratio = 0.75
        clamped_step = min(max(step_ratio, 0.0), 1.0)
        temporal_decay = 0.05 + 0.95 * (0.5 * (1.0 + np.cos(np.pi * clamped_step)))
        logger.debug(f"📉 [Temporal Decay] Weight calculated: {temporal_decay:.4f} for step_ratio: {step_ratio:.3f}")

        # 3. معالجة الإشارة بدون إتلاف القيم المنسوبة فيزياوياً (Preserving Dynamics)
        # نقوم بتقييد القيم لتجنب الطفرات الضارة بـ Latent دون ضغط المدى القسري
        scaled_control = torch.clamp(control_tensor, min=0.0)

        # 4. حساب مصفوفة الكسب النهائية
        gain_tensor = scaled_control * temporal_decay * effective_strength

        logger.info(
            f"✨ [Control Gain Output] Applied | Peak Gain Abs: {gain_tensor.max().item():.6f} | "
            f"Mean Gain: {gain_tensor.mean().item():.6f}"
        )
        return gain_tensor


if __name__ == "__main__":
    logger.info("=== بدء الاختبار الذاتي لمحرك ControlNet لـ Latent (LatentControlNetEngine) ===")

    # 1. تحديد كرت الشاشة أو المعالج المتوفر
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dtype = torch.float32
    logger.info(f"🖥️ جهاز التشغيل المستهدف: {device} | Dtype: {dtype}")

    # 2. تهيئة المحرك
    cn_engine = LatentControlNetEngine(default_strength=0.85)

    # 3. اختبار إدخال NumPy array ثنائي الأبعاد (محاكاة لمصفوفة حواف/Depth)
    logger.info("🧪 [Test 1] معالجة مدخلات NumPy Array...")
    numpy_input = np.random.rand(256, 256).astype(np.float32)
    prepared_from_np = cn_engine.prepare_control_tensor(
        control_input=numpy_input,
        target_shape=(64, 64),
        device=device,
        dtype=dtype
    )

    # 4. اختبار إدخال None
    logger.info("🧪 [Test 2] معالجة مدخلات None...")
    prepared_none = cn_engine.prepare_control_tensor(
        control_input=None,
        target_shape=(64, 64),
        device=device,
        dtype=dtype
    )

    # 5. اختبار حساب Control Gain مع تقدم الخطوات الزمانية (Temporal Decay)
    logger.info("🧪 [Test 3] حساب Control Gain في خطوة أولية (Step Ratio = 0.1)...")
    gain_early = cn_engine.compute_control_gain(
        control_tensor=prepared_from_np,
        step_ratio=0.1,
        strength=1.0
    )

    logger.info("🧪 [Test 4] حساب Control Gain في خطوة متأخرة (Step Ratio = 0.8)...")
    gain_late = cn_engine.compute_control_gain(
        control_tensor=prepared_from_np,
        step_ratio=0.8,
        strength=1.0
    )

    logger.info(f"📊 أقصى كسب في الخطوة المبكرة: {gain_early.max().item():.6f}")
    logger.info(f"📊 أقصى كسب في الخطوة المتأخرة (انخفاض التوجيه): {gain_late.max().item():.6f}")

    logger.info("=== اكتملت جميع اختبارات LatentControlNetEngine بنجاح تام ===")